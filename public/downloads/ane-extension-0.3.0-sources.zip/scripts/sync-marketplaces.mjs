import { readFile, writeFile } from 'node:fs/promises';
const source = await readFile(new URL('../../AneCore/MarketplaceCatalog.cs', import.meta.url), 'utf8');
const entries = [...source.matchAll(/new\(Platform\.(\w+), \[(.*?)\], @"(.*?)"(?:, "([^"]*)")?(?:, "([^"]*)")?\)/g)].map(([, platform, domains, pattern, country, currency]) => ({
  platform, hosts: [...domains.matchAll(/"([^"]+)"/g)].map(match => match[1]), pattern: pattern.replaceAll('(?<id>', '('), country: country ?? '', currency: currency ?? '',
}));
if (entries.length < 20) throw new Error('Marketplace catalog format changed; review sync parser.');
const generated = '// Generated from AneCore/MarketplaceCatalog.cs by scripts/sync-marketplaces.mjs.\nexport const marketplaceRegistry = ' + JSON.stringify(entries, null, 2) + ' as const;\n';
const target = new URL('../utils/marketplaceRegistry.ts', import.meta.url);
if (process.argv.includes('--check')) {
  if (await readFile(target, 'utf8') !== generated) throw new Error('Extension marketplace registry differs from AneCore. Run npm run sync:marketplaces.');
  console.log(`Marketplace catalog parity passed (${entries.length} platforms).`);
} else await writeFile(target, generated);
