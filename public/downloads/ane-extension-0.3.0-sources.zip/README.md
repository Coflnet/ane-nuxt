# AneExension

Ane Deals browser extension, built with WXT, Vue and TypeScript. Press the extension on an individual marketplace listing to save its public details and show available price comparisons in the popup and an on-page panel. Browsing by itself never collects listings or opens background marketplace tabs.

## Install and verify

Node.js 22.6+ and pnpm 10+ (npm also works with the existing dependencies):

```sh
pnpm install
pnpm build
pnpm build:firefox
pnpm typecheck
pnpm test
pnpm test:catalog
pnpm test:browser
```

Load `AneExension/.output/chrome-mv3` with **Load unpacked** in `chrome://extensions`, or the Firefox bundle in `.output/firefox-mv2` using Firefox's temporary add-on loader. `pnpm zip` and `pnpm zip:firefox` create release archives. No store publication is performed by building.

The discovery and personal-flip endpoints added in the sibling AneApi/Core changes must be built and deployed before this package can use them on the live Ane service. The browser fixture tests exercise their contract locally; a successful package build does not deploy the API.

## Use

1. Sign in at https://ane.deals and keep its tab open while connecting the extension. The extension exchanges the signed-in Firebase token for an Ane API token; tokens are confined to extension contexts.
2. Open an individual listing, then press Ane Deals in the toolbar. Its canonical URL, title, public description, price/currency, image, condition, explicit availability and publisher listing timestamp (when present) are sent to the authenticated discovery endpoint. Search and catalog pages are excluded. Browser captures are labeled unverified. They can create an initial asking-price snapshot, but cannot overwrite an existing server listing. Browser availability never declares a sale or withdrawal, and browser publisher timestamps are advisory rather than authoritative. Independent server observations determine sale status.
3. The popup and page panel show similar active listings, observed availability and up to ten sale references. Estimates distinguish active asking prices, last asking prices of listings marked sold, and last asking prices of reported or inferred sales. For supported disappearance checks, removal within 2–48 hours is labeled an inferred sale, with age measured since the publisher timestamp or first observation as stated beside the reference. Other withdrawals remain sale unconfirmed. These advertised prices are proxies, not confirmed transaction amounts. A new listing may have no estimate until processing finishes; selecting a product candidate requests comparisons without altering automatic grouping.
4. Choose **Track this flip** to record purchase/target/sale prices, currency, fees, shipping, notes and status. **My flips** lists your saved records, calculates realized or target profit in each record's currency, and lets you edit or delete them. Records load in bounded pages; **Load more flips** retrieves the next page. The popup sorts recent updates within the loaded records, rather than claiming to show the globally newest flips first. Tracking the same listing again preserves existing accounting.
5. **Create a listing alert** opens the alert-creation page with the listing title and price. On any HTTPS product page, choose **Select a reference price on this page**, then click a visible price including its currency. Shift+click adds shipping or extras in the same currency; an ordinary click starts a new selection. The picker confirms the total before **Create alert on Ane Deals** opens the form. Escape or Cancel stops selection. Only the chosen price/selector, page URL and title enter the link; no raw HTML, sign-in or cookies are forwarded.
6. The form preserves the selected XPath and extras. **Preview reference** checks the public server's access to those exact elements. Daily refresh only works when those prices are publicly accessible; authenticated or browser-only content can set the initial threshold but cannot grant the server that access. Missing elements, missing extras or a changed currency preserve the existing threshold instead of substituting another page price.

The manifest requests `activeTab`, `scripting` and `storage`, plus only the two Ane service origins. Marketplace access comes from pressing the extension action; there are no automatic marketplace content scripts, alarms, passive contributions or crowd-scrape settings.

## Marketplace coverage

The extension uses the same individual-listing URL catalog as AneCore: eBay country sites, Kleinanzeigen, Vinted country sites, Marktplaats, Willhaben, Shpock, Facebook Marketplace, Leboncoin, Wallapop, OLX, Subito, Milanuncios, Allegro, Allegro Lokalnie, 2dehands/2ememain, Ricardo, Tutti, Anibis, Tradera, Blocket, Finn, Tori, DBA, Bazos, Sbazar, Adverts, DoneDeal, ParuVendu, Rakuten France, Catawiki, Delcampe, Depop, Gumtree, Quoka, Markt.de, Vendora, Jófogás and Njuškalo.

This is URL recognition and browser-assisted discovery, not a claim that every site's live markup or automated crawler works. Extraction prefers the current listing's JSON-LD Product/offer metadata, then public heading/Open Graph/price elements. Missing prices and currencies remain unknown; login-only pages or missing titles cannot be captured. Cardmarket product catalog pages are not individual second-hand offers and are excluded.

`utils/marketplaceRegistry.ts` is generated from `../AneCore/MarketplaceCatalog.cs`. After catalog edits run `pnpm sync:marketplaces`; `pnpm test:catalog` detects drift. The built extension remains self-contained.

## Tests

`pnpm test` checks canonical identities, host spoofing rejection, EU price parsing, unsafe URLs, correct metadata selection, sold availability and publisher timestamps. `pnpm test:catalog` verifies all catalog fields against Core.

Set `CHROMIUM_PATH=/path/to/chromium` to use an existing browser instead of Playwright's bundled revision.

`pnpm test:browser` runs Chromium against local mocked marketplace/API responses: real built popup UI, content-script extraction and panel mounting, Firebase token exchange, authentication/error handling, 429/503/timeouts and recovery, repeated action/navigation handling, safe links and flip creation/editing/selling/deletion and paging beyond 100 records. Browser automation cannot synthesize a toolbar gesture's `activeTab` grant or inspect Chrome's toolbar target, so only the temporary test copy receives a fixture-origin permission and its popup's active-tab query is redirected to the fixture. The shipped manifest is asserted unchanged. This test does not contact real marketplaces or require a live account. Live marketplace markup and manual toolbar activation still need browser review before publication.

To exercise the extension's generated alert link through the actual Nuxt form and Core selector parser, build/start the sibling frontend on `127.0.0.1:4173`, run the synthetic preview fixture with `dotnet run --project tests/reference-fixture --artifacts-path /tmp/ane-reference-flow-build`, then run:

```sh
NUXT_TEST_URL=http://127.0.0.1:4173 REFERENCE_TEST_URL=http://127.0.0.1:4174 pnpm test:browser
```

The optional integration mode proxies production origins to those local fixtures, disables live Firebase sign-in, and verifies prefill, exact server selection with shipping, removal of the last extra, and an inaccessible browser-only selection retaining its threshold. The fixture requires the sibling AneCore source and .NET 10; it never fetches a real marketplace or uses an account.
