import { parsePrice, safeUrl } from './storeDetectors';

// No page HTML or credentials are copied: only explicitly picked prices and their XPath.
export function startReferencePicker(): () => void {
  const host = document.createElement('div');
  host.id = 'ane-reference-picker';
  const shadow = host.attachShadow({ mode: 'closed' });
  const panel = document.createElement('aside');
  panel.style.cssText = 'position:fixed;right:20px;top:20px;width:320px;padding:16px;background:#181825;color:#cdd6f4;font:14px/1.5 system-ui;border:2px solid #cba6f7;border-radius:12px;z-index:2147483647';
  const instruction = document.createElement('p');
  instruction.textContent = 'Click the price on this page. Shift+click adds shipping or extras. Escape cancels.';
  const status = document.createElement('p');
  status.setAttribute('role', 'status');
  const link = document.createElement('a');
  link.textContent = 'Create alert on Ane Deals ↗';
  link.style.cssText = 'display:none;color:#89b4fa';
  link.target = '_blank'; link.rel = 'noopener noreferrer';
  const privacy = document.createElement('small');
  privacy.textContent = 'Only your selected price, selectors, page title and URL are passed to Ane. Daily refresh requires public server access. Sign-in and cookies stay here.';
  const close = document.createElement('button');
  close.textContent = 'Cancel';
  const picks: { selector: string; price: number; currency: string }[] = [];
  let highlighted: HTMLElement | undefined;
  let previousOutline = '';
  const restore = () => { if (highlighted) highlighted.style.outline = previousOutline; highlighted = undefined; };
  const stop = () => {
    restore(); host.remove();
    document.removeEventListener('click', pick, true);
    document.removeEventListener('mouseover', hover, true);
    document.removeEventListener('keydown', key, true);
  };
  const key = (event: KeyboardEvent) => { if (event.key === 'Escape') { event.preventDefault(); stop(); } };
  const hover = (event: MouseEvent) => {
    restore();
    if (event.target instanceof HTMLElement && !event.composedPath().includes(host)) {
      highlighted = event.target; previousOutline = highlighted.style.outline;
      highlighted.style.outline = '2px solid #a855f7';
    }
  };
  const pick = (event: MouseEvent) => {
    if (event.composedPath().includes(host) || !event.isTrusted) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (!(event.target instanceof HTMLElement) || event.target.closest('input,textarea,select,[contenteditable]')) return;
    const text = event.target.innerText.trim();
    const parsed = parsePrice(text);
    if (text.length > 180 || !parsed.currency || parsed.price == null || parsed.price <= 0 || parsed.price > 100_000) {
      status.textContent = 'Choose a single price with its currency, for example €100.00.'; return;
    }
    const selector = referenceXPath(event.target);
    if (!event.shiftKey) picks.length = 0;
    if (picks.length && picks[0].currency !== parsed.currency) { status.textContent = 'All selected prices must use the same currency.'; return; }
    if (!picks.some(pick => pick.selector === selector) && picks.length < 12) picks.push({ selector, price: parsed.price, currency: parsed.currency });
    const total = Math.round(picks.reduce((sum, pick) => sum + pick.price, 0) * 100) / 100;
    const url = safeUrl(location.href);
    if (!url) return;
    const title = (document.querySelector('h1')?.textContent ?? document.title).trim().slice(0, 300);
    const query = new URLSearchParams({ searchValue: title, maxPrice: String(Math.ceil(total)), referenceUrl: url,
      referenceTitle: title, referenceSelector: picks[0].selector, referencePrice: String(total), referenceCurrency: picks[0].currency,
      referenceAdditionalSelectors: picks.slice(1).map(pick => pick.selector).join('\n') });
    link.href = `https://ane.deals/filters/create?${query}`;
    link.style.display = 'block';
    status.textContent = `Selected ${picks.length} price${picks.length === 1 ? '' : 's'}: ${new Intl.NumberFormat(undefined, { style: 'currency', currency: parsed.currency }).format(total)}`;
  };
  close.addEventListener('click', stop);
  panel.append(close, instruction, status, link, privacy); shadow.append(panel); document.documentElement.append(host);
  document.addEventListener('click', pick, true);
  document.addEventListener('mouseover', hover, true);
  document.addEventListener('keydown', key, true);
  return stop;
}

export function referenceXPath(element: Element): string {
  const segments: string[] = [];
  for (let current: Element | null = element; current; current = current.parentElement) {
    // Stable unique IDs survive unrelated markup changes better than a positional path.
    if (current.id && !current.id.includes("'") && document.querySelectorAll(`#${CSS.escape(current.id)}`).length === 1)
      return `//*[@id='${current.id}']${segments.length ? '/' + segments.join('/') : ''}`;
    let index = 1;
    for (let sibling = current.previousElementSibling; sibling; sibling = sibling.previousElementSibling)
      if (sibling.tagName === current.tagName) index++;
    segments.unshift(`${current.tagName.toLowerCase()}[${index}]`);
  }
  return '/' + segments.join('/');
}
