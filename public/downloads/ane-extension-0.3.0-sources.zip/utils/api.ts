export const DEFAULT_BASE = 'https://ane.coflnet.com';

export interface ProductMatch {
  title: string; price: number; currency: string; platform: string; listingUrl: string; postedAt: string; imageUrl?: string;
}

async function getToken(): Promise<string | null> {
  const data = await browser.storage.local.get('aneToken');
  return (data as Record<string, string>).aneToken ?? null;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = await getToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...((options.headers ?? {}) as Record<string, string>),
  };
  let res: Response;
  try { res = await fetch(`${DEFAULT_BASE}${path}`, { ...options, headers, signal: AbortSignal.timeout(15_000) }); }
  catch (error) {
    if (error instanceof DOMException && error.name === 'TimeoutError') throw new Error('Ane Deals request timed out. Please retry.');
    throw new Error('Could not reach Ane Deals. Check your connection and retry.');
  }
  if (!res.ok) {
    if (res.status === 401) {
      await browser.storage.local.remove(['aneToken', 'tokenSavedAt']);
      throw new Error('Your sign-in expired. Open Ane Deals, sign in and retry.');
    }
    if (res.status === 429) throw new Error('Too many requests (429). Wait a moment and retry.');
    if (res.status >= 500) throw new Error(`Ane Deals is temporarily unavailable (${res.status}). Please retry.`);
    throw new Error(`${res.status} ${res.statusText} – ${path}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export interface DiscoveryRequest {
  url: string; title: string; description?: string; price?: number; currency?: string;
  imageUrl?: string; condition?: string; locale?: string; productId?: string; availability?: 'available' | 'sold' | 'unavailable'; createdAt?: string;
}
export interface DiscoveryResult {
  listing: { id: string; platform: string; url: string; title: string; price?: number; currency?: string; imageUrls: string[]; browserCaptureUnverified?: boolean };
  stored: boolean; queued: boolean; productId: string | null;
  estimate: { value: number; currency: string; source: string; sampleCount: number } | null;
  similarListings: ProductMatch[];
  productCandidates: { id: string; name: string }[];
  saleStatus?: { status: 'available' | 'withdrawn' | 'reported_sold' | 'inferred_sold' | 'unknown'; ageBasis?: string | null; checkedAt?: string; lastAvailableAt?: string | null; firstUnavailableAt?: string | null; soldObservedAt?: string | null } | null;
  saleReferences?: { listingId: string; platform: string; url: string; title: string; price: number; currency: string; status: 'reported_sold' | 'inferred_sold' | 'withdrawn'; evidence: string; ageBasis?: string | null; observedAt: string }[];
}
export const priceEstimateLabel = (source?: string) => source === 'sold_reference_asking_median'
  ? 'Last asking prices of listings marked sold' : source === 'inferred_sale_asking_median'
    ? 'Last asking prices of reported or inferred sales' : 'Median active asking prices';
export type FlipStatus = 'watching' | 'bought' | 'listed' | 'sold' | 'archived';
export interface FlipInput {
  url: string; title?: string; purchasePrice?: number | null; targetPrice?: number | null;
  fees: number; shippingCost: number; salePrice?: number | null; currency: string;
  status: FlipStatus; notes: string;
}
export interface UserFlip extends FlipInput {
  id: string; platform: string; listingId: string; profit?: number | null; createdAt: string; updatedAt: string;
}
export const discoverListing = (listing: DiscoveryRequest) => request<DiscoveryResult>('/api/extension/discover', { method: 'POST', body: JSON.stringify(listing) });
export interface UserFlipPage { items: UserFlip[]; nextCursor: string | null; }
export const getUserFlips = (cursor?: string | null) => request<UserFlipPage>(`/api/user/flips?limit=100${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
export const saveUserFlip = (flip: FlipInput, id?: string) => {
  const { url, ...editable } = flip;
  return request<UserFlip>(`/api/user/flips${id ? `/${encodeURIComponent(id)}` : ''}`, { method: id ? 'PATCH' : 'POST', body: JSON.stringify(id ? editable : { url, ...editable }) });
};
export const deleteUserFlip = async (id: string) => { await request<unknown>(`/api/user/flips/${encodeURIComponent(id)}`, { method: 'DELETE' }); };
