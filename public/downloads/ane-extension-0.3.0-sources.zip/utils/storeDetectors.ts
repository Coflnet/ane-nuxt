// Only public listing fields are extracted, after the browser action is pressed.
export interface PageProduct {
  url: string;
  title: string;
  description?: string;
  price?: number;
  currency?: string;
  imageUrl?: string;
  condition?: string;
  locale?: string;
  platform: string;
  listingId: string;
  availability?: 'available' | 'sold' | 'unavailable';
  createdAt?: string;
}

import { marketplaceRegistry } from './marketplaceRegistry.ts';
export const marketplaces = marketplaceRegistry.map(m => ({ ...m, path: new RegExp(m.pattern, 'i') }));

export function listingIdentity(value: string): { platform: string; listingId: string; url: string } | null {
  try {
    const url = new URL(value);
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.port) return null;
    const market = marketplaces.find(m => m.hosts.some(host => url.hostname === host || url.hostname.endsWith(`.${host}`)));
    const match = market?.path.exec(url.pathname);
    if (!market || !match) return null;
    let id = match.slice(1).find(value => value !== undefined) ?? '';
    if (market.platform === 'Finn' && !id) id = url.searchParams.get('finnkode') ?? '';
    if (!id || id.length > 512 || (market.platform === 'Finn' && !/^\d+$/.test(id))) return null;
    if (market.platform === 'OLX' || market.platform === 'Bazos') id = url.hostname.split('.').at(-1) + ':' + id;
    const finnCode = market.platform === 'Finn' && url.pathname.endsWith('ad.html') ? id : undefined;
    url.protocol = 'https:'; url.search = ''; url.hash = '';
    if (finnCode) url.searchParams.set('finnkode', finnCode);
    return { platform: market.platform, listingId: id, url: url.href };
  } catch { return null; }
}

export function safeUrl(value: unknown, base?: string): string | undefined {
  if (typeof value !== 'string') return undefined;
  try {
    const url = new URL(value, base);
    return url.protocol === 'https:' && !url.username && !url.password ? url.href : undefined;
  } catch { return undefined; }
}

export function parsePrice(text: string): { price?: number; currency?: string } {
  const currency = /\b(EUR|GBP|USD|PLN|CZK|DKK|SEK|HUF|RON|BGN|NOK|CHF)\b/i.exec(text)?.[1].toUpperCase()
    ?? (/€/.test(text) ? 'EUR' : /£/.test(text) ? 'GBP' : /\$/.test(text) ? 'USD' : /zł/i.test(text) ? 'PLN' : /Kč/.test(text) ? 'CZK' : undefined);
  if (/-\s*\d/.test(text)) return { currency };
  let numeric = /\d[\d\s\u00a0\u202f.,]*/.exec(text)?.[0].replace(/[\s\u00a0\u202f]/g, '').replace(/[.,]$/, '');
  if (!numeric) return { currency };
  const decimal = numeric.match(/[.,](\d{1,2})$/);
  numeric = decimal ? numeric.slice(0, -decimal[0].length).replace(/[.,]/g, '') + '.' + decimal[1] : numeric.replace(/[.,]/g, '');
  const price = Number(numeric);
  return { price: Number.isFinite(price) && price >= 0 ? price : undefined, currency };
}

export function detectStorePage(doc: Document = document, pageUrl: string = location.href): PageProduct | null {
  const identity = listingIdentity(pageUrl);
  if (!identity) return null;
  const meta = (name: string) => doc.querySelector<HTMLMetaElement>(`meta[property="${name}"], meta[name="${name}"]`)?.content;
  const nodes: Record<string, unknown>[] = [];
  const collect = (value: unknown, depth = 0) => {
    if (depth > 8 || nodes.length >= 100) return;
    if (Array.isArray(value)) { value.slice(0, 100).forEach(v => collect(v, depth + 1)); return; }
    if (value && typeof value === 'object') {
      const node = value as Record<string, unknown>;
      const types = Array.isArray(node['@type']) ? node['@type'] : [node['@type']];
      if (types.some(type => type === 'Product' || type === 'IndividualProduct')) nodes.push(node);
      for (const key of ['@graph', 'mainEntity', 'itemListElement', 'item']) collect(node[key], depth + 1);
    }
  };
  for (const script of Array.from(doc.querySelectorAll('script[type="application/ld+json"]')).slice(0, 20)) {
    const text = script.textContent ?? '';
    if (text.length > 250_000) continue;
    try { collect(JSON.parse(text)); } catch { /* malformed publisher metadata */ }
  }
  // Match the canonical listing rather than recommended products embedded in the page.
  const nodeIdentity = (node: Record<string, unknown>) => listingIdentity(safeUrl(node.url, pageUrl) ?? '');
  const product = nodes.find(node => {
    const candidate = nodeIdentity(node);
    return candidate?.platform === identity.platform && candidate.listingId === identity.listingId;
  }) ?? (nodes.length === 1 && !nodes[0].url ? nodes[0] : undefined);
  const text = (selector: string) => doc.querySelector(selector)?.textContent?.trim();
  const title = String(product?.name ?? text('h1#viewad-title, h1[data-testid="item-title"], h1.x-item-title__mainTitle, #itemTitle, #titletextonly, h1') ?? meta('og:title') ?? '').trim().slice(0, 300);
  if (!title) return null;
  const offers = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
  const offer = offers && typeof offers === 'object' ? offers as Record<string, unknown> : undefined;
  const rawPrice = offer?.price ?? meta('product:price:amount') ?? doc.querySelector('[itemprop="price"]')?.getAttribute('content');
  const parsed = rawPrice != null && /^\d+(?:\.\d+)?$/.test(String(rawPrice))
    ? { price: Number(rawPrice), currency: undefined }
    : parsePrice(String(rawPrice ?? text('#viewad-price, [data-testid="item-price"], [data-testid="ad-price"], [data-test="price-info-price"], .x-price-primary .ux-textspans, #prcIsum, [itemprop="price"], .price') ?? ''));
  const currencyValue = String(offer?.priceCurrency ?? meta('product:price:currency') ?? parsed.currency ?? '').toUpperCase();
  const images = product?.image;
  const image = Array.isArray(images) ? images[0] : images;
  // Only publisher listing dates; never extraction time or modification date.
  const posted = product?.datePosted ?? product?.datePublished;
  const postedAt = typeof posted === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(posted) ? Date.parse(posted) : NaN;
  return {
    ...identity, title,
    createdAt: Number.isFinite(postedAt) && postedAt <= Date.now() ? new Date(postedAt).toISOString() : undefined,
    availability: typeof offer?.availability !== 'string' ? undefined : /(?:SoldOut)(?:$|[/?#])/i.test(offer.availability) ? 'sold' : /(?:OutOfStock|Discontinued)(?:$|[/?#])/i.test(offer.availability) ? 'unavailable' : /(?:InStock|LimitedAvailability|OnlineOnly)(?:$|[/?#])/i.test(offer.availability) ? 'available' : undefined,
    description: String(product?.description ?? meta('og:description') ?? meta('description') ?? '').trim().slice(0, 4000) || undefined,
    price: parsed.price != null && Number.isFinite(parsed.price) && parsed.price >= 0 ? parsed.price : undefined,
    currency: /^[A-Z]{3}$/.test(currencyValue) ? currencyValue : undefined,
    imageUrl: safeUrl(typeof image === 'object' && image ? (image as Record<string, unknown>).url : image ?? meta('og:image'), pageUrl),
    condition: typeof offer?.itemCondition === 'string' ? offer.itemCondition.slice(0, 64) : undefined,
    locale: doc.documentElement.lang.slice(0, 16) || undefined,
  };
}

export function cssSelector(el: Element): string {
  if (el.id) return `#${CSS.escape(el.id)}`;
  return el.tagName.toLowerCase() + Array.from(el.classList).slice(0, 2).map(cls => `.${CSS.escape(cls)}`).join('');
}
