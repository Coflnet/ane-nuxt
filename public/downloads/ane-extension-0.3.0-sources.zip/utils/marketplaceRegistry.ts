// Generated from AneCore/MarketplaceCatalog.cs by scripts/sync-marketplaces.mjs.
export const marketplaceRegistry = [
  {
    "platform": "Ebay",
    "hosts": [
      "ebay.de",
      "ebay.at",
      "ebay.ch",
      "ebay.co.uk",
      "ebay.fr",
      "ebay.it",
      "ebay.es",
      "ebay.nl",
      "ebay.be",
      "ebay.com.be",
      "ebay.pl",
      "ebay.ie",
      "ebay.com"
    ],
    "pattern": "^/itm/(?:[^/]+/)?(\\d+)(?:/|$)",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Kleinanzeigen",
    "hosts": [
      "kleinanzeigen.de"
    ],
    "pattern": "^/s-anzeige/[^/]+/(\\d+)-\\d+-\\d+/?$",
    "country": "DE",
    "currency": ""
  },
  {
    "platform": "Marktplaats",
    "hosts": [
      "marktplaats.nl"
    ],
    "pattern": "^/v/.*/([ma]\\d+)(?:-[^/]*)?/?$",
    "country": "NL",
    "currency": ""
  },
  {
    "platform": "Willhaben",
    "hosts": [
      "willhaben.at"
    ],
    "pattern": "^/iad/(kaufen-und-verkaufen/d/[^/]+-\\d+)/?$",
    "country": "AT",
    "currency": ""
  },
  {
    "platform": "Vinted",
    "hosts": [
      "vinted.de",
      "vinted.at",
      "vinted.fr",
      "vinted.it",
      "vinted.es",
      "vinted.pt",
      "vinted.nl",
      "vinted.be",
      "vinted.pl",
      "vinted.cz",
      "vinted.sk",
      "vinted.hu",
      "vinted.ro",
      "vinted.hr",
      "vinted.lt",
      "vinted.lv",
      "vinted.ee",
      "vinted.fi",
      "vinted.se",
      "vinted.dk",
      "vinted.gr",
      "vinted.ie",
      "vinted.co.uk",
      "vinted.lu",
      "vinted.com"
    ],
    "pattern": "^/items/(\\d+)(?:-[^/]*)?/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Shpock",
    "hosts": [
      "shpock.com"
    ],
    "pattern": "^/(?:[^/]+/)?i/([^/]+)(?:/[^/]*)?/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Facebook",
    "hosts": [
      "facebook.com"
    ],
    "pattern": "^/marketplace/item/(\\d+)/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Lebecoin",
    "hosts": [
      "leboncoin.fr"
    ],
    "pattern": "^/ad/[^/]+/(\\d+)/?$",
    "country": "FR",
    "currency": ""
  },
  {
    "platform": "Wallapop",
    "hosts": [
      "wallapop.com"
    ],
    "pattern": "^/item/[^/]+-(\\d+)/?$",
    "country": "ES",
    "currency": ""
  },
  {
    "platform": "OLX",
    "hosts": [
      "olx.pl",
      "olx.pt",
      "olx.ro",
      "olx.bg",
      "olx.ua"
    ],
    "pattern": "^/(?:d/)?(?:oferta|anuncio|item)/[^/]*-(ID[a-zA-Z0-9]+)\\.html/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Subito",
    "hosts": [
      "subito.it"
    ],
    "pattern": "^/[^/]+/[^/]+-(\\d+)\\.htm$",
    "country": "IT",
    "currency": ""
  },
  {
    "platform": "Milanuncios",
    "hosts": [
      "milanuncios.com"
    ],
    "pattern": "^/[^/]+/[^/]+-(\\d+)\\.htm$",
    "country": "ES",
    "currency": ""
  },
  {
    "platform": "Allegro",
    "hosts": [
      "allegro.pl",
      "allegro.cz",
      "allegro.sk",
      "allegro.hu"
    ],
    "pattern": "^/(?:oferta|nabidka|ponuka|ajanlat)/[^/]+-(\\d+)/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "AllegroLokalnie",
    "hosts": [
      "allegrolokalnie.pl"
    ],
    "pattern": "^/oferta/([^/]+)/?$",
    "country": "PL",
    "currency": "PLN"
  },
  {
    "platform": "TwoDehands",
    "hosts": [
      "2dehands.be",
      "2ememain.be"
    ],
    "pattern": "^/v/.*/([ma]\\d+)(?:-[^/]*)?/?$",
    "country": "BE",
    "currency": ""
  },
  {
    "platform": "Ricardo",
    "hosts": [
      "ricardo.ch"
    ],
    "pattern": "^/[^/]+/a/[^/]+-(\\d+)/?$",
    "country": "CH",
    "currency": "CHF"
  },
  {
    "platform": "Tutti",
    "hosts": [
      "tutti.ch"
    ],
    "pattern": "^/[^/]+/vi/.*/(\\d+)/?$",
    "country": "CH",
    "currency": "CHF"
  },
  {
    "platform": "Anibis",
    "hosts": [
      "anibis.ch"
    ],
    "pattern": "^/[^/]+/d/[^/]+-(\\d+)/?$",
    "country": "CH",
    "currency": "CHF"
  },
  {
    "platform": "Tradera",
    "hosts": [
      "tradera.com"
    ],
    "pattern": "^/item/\\d+/(\\d+)(?:/[^/]*)?/?$",
    "country": "SE",
    "currency": "SEK"
  },
  {
    "platform": "Blocket",
    "hosts": [
      "blocket.se"
    ],
    "pattern": "^(?:/annons/(?:[^/]+/)*(\\d+)|/recommerce/forsale/item/(\\d+))/?$",
    "country": "SE",
    "currency": "SEK"
  },
  {
    "platform": "Finn",
    "hosts": [
      "finn.no"
    ],
    "pattern": "^/(?:bap/forsale/ad\\.html|recommerce/forsale/item/(\\d+))/?$",
    "country": "NO",
    "currency": "NOK"
  },
  {
    "platform": "Tori",
    "hosts": [
      "tori.fi"
    ],
    "pattern": "^/(?:recommerce/forsale/item/(\\d+)|[^/]+/[^/]+_(\\d+)\\.htm)/?$",
    "country": "FI",
    "currency": ""
  },
  {
    "platform": "DBA",
    "hosts": [
      "dba.dk"
    ],
    "pattern": "^/(?:recommerce/forsale/item/(\\d+)|[^/]+/id-(\\d+))/?$",
    "country": "DK",
    "currency": "DKK"
  },
  {
    "platform": "Bazos",
    "hosts": [
      "bazos.cz",
      "bazos.sk",
      "bazos.pl"
    ],
    "pattern": "^/inzerat/(\\d+)(?:/[^/]*)?/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Sbazar",
    "hosts": [
      "sbazar.cz"
    ],
    "pattern": "^/[^/]+/detail/(\\d+)(?:-[^/]*)?/?$",
    "country": "CZ",
    "currency": "CZK"
  },
  {
    "platform": "Adverts",
    "hosts": [
      "adverts.ie"
    ],
    "pattern": "^/[^/]+/[^/]+/(\\d+)/?$",
    "country": "IE",
    "currency": ""
  },
  {
    "platform": "DoneDeal",
    "hosts": [
      "donedeal.ie"
    ],
    "pattern": "^/[^/]+/[^/]+/(\\d+)/?$",
    "country": "IE",
    "currency": ""
  },
  {
    "platform": "ParuVendu",
    "hosts": [
      "paruvendu.fr"
    ],
    "pattern": "^/annonces/.*/(\\d+)A\\d+.*$",
    "country": "FR",
    "currency": ""
  },
  {
    "platform": "Rakuten",
    "hosts": [
      "fr.shopping.rakuten.com"
    ],
    "pattern": "^/offer/buy/(\\d+)(?:/[^/]*)?/?$",
    "country": "FR",
    "currency": ""
  },
  {
    "platform": "Catawiki",
    "hosts": [
      "catawiki.com"
    ],
    "pattern": "^/[^/]+/l/(\\d+)(?:-[^/]*)?/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Delcampe",
    "hosts": [
      "delcampe.net"
    ],
    "pattern": "^/[^/]+/collectibles/.*/[^/]+-(\\d+)\\.html$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Depop",
    "hosts": [
      "depop.com"
    ],
    "pattern": "^/products/([^/]+)/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Gumtree",
    "hosts": [
      "gumtree.com"
    ],
    "pattern": "^/p/.*/(\\d+)/?$",
    "country": "GB",
    "currency": "GBP"
  },
  {
    "platform": "Quoka",
    "hosts": [
      "quoka.de"
    ],
    "pattern": "^/anzeigen/.*/(?:ad|anzeige)/[^/]+/([^/]+)\\.html$",
    "country": "DE",
    "currency": ""
  },
  {
    "platform": "MarktDe",
    "hosts": [
      "markt.de"
    ],
    "pattern": "^/.*?/a/([^/]+)/?$",
    "country": "DE",
    "currency": ""
  },
  {
    "platform": "Vendora",
    "hosts": [
      "vendora.gr",
      "vendora.cy"
    ],
    "pattern": "^/items/([^/]+)(?:/[^/]*)?/?$",
    "country": "",
    "currency": ""
  },
  {
    "platform": "Jofogas",
    "hosts": [
      "jofogas.hu"
    ],
    "pattern": "^/[^/]+/[^/]+_(\\d+)\\.htm$",
    "country": "HU",
    "currency": "HUF"
  },
  {
    "platform": "Njuskalo",
    "hosts": [
      "njuskalo.hr"
    ],
    "pattern": "^/[^/]+/[^/]+-oglas-(\\d+)/?$",
    "country": "HR",
    "currency": ""
  }
] as const;
