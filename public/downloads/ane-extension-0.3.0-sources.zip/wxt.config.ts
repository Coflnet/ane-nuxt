import { defineConfig } from 'wxt';

export default defineConfig({
  modules: ['@wxt-dev/module-vue'],
  zip: {
    includeSources: ['.gitignore', 'tests/**/*.test.ts'],
    excludeSources: ['tests/*.png', 'tests/*-result.json', '**/bin/**', '**/obj/**'],
  },
  manifest: {
    name: 'Ane Deals – Marketplace & Flips',
    short_name: 'Ane Deals',
    description: 'Select reference prices on a page, compare marketplace listings and manage your flips.',
    version: '0.3.0',
    permissions: ['activeTab', 'storage', 'scripting'],
    host_permissions: ['https://ane.deals/*', 'https://ane.coflnet.com/*'],
    action: { default_popup: 'popup.html', default_title: 'Compare this listing with Ane Deals' },
  },
});
