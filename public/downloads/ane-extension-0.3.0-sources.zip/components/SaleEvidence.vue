<template>
  <section v-if="discovery.saleStatus || references.length">
    <p v-if="discovery.saleStatus">Observed listing status: {{ statusLabel(discovery.saleStatus.status, discovery.saleStatus.ageBasis) }}<small v-if="statusDate">Observed {{ observedDate(statusDate) }}</small></p>
    <template v-if="references.length">
      <h2>Sale references</h2><p>Advertised prices, not confirmed transaction prices. Disappearance within 2–48 hours is an inferred sale; other removals are excluded from sale estimates.</p>
      <a v-for="reference in references" :key="`${reference.platform}:${reference.listingId}`" :href="reference.url" target="_blank" rel="noopener noreferrer">
        <strong>{{ money(reference.price, reference.currency) }}</strong> {{ reference.title }}
        <small>{{ statusLabel(reference.status, reference.ageBasis) }} · {{ reference.platform }} · observed {{ observedDate(reference.observedAt) }}</small>
      </a>
    </template>
  </section>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import type { DiscoveryResult } from '../utils/api';
import { safeUrl } from '../utils/storeDetectors';
const props = defineProps<{ discovery: DiscoveryResult }>();
const references = computed(() => (props.discovery.saleReferences ?? []).filter(r => safeUrl(r.url)).slice(0, 10));
const statusDate = computed(() => ['reported_sold', 'inferred_sold'].includes(props.discovery.saleStatus?.status ?? '') ? props.discovery.saleStatus?.soldObservedAt : props.discovery.saleStatus?.status === 'withdrawn' ? props.discovery.saleStatus.firstUnavailableAt : props.discovery.saleStatus?.lastAvailableAt);
const statusLabel = (status: string, ageBasis?: string | null) => status === 'inferred_sold'
  ? `Inferred sale; disappeared within 2–48 hours${ageBasis === 'first_seen' ? ' since first seen' : ageBasis === 'listing_created_at' ? ' since listing posted' : ''}`
  : ({ available: 'Available', reported_sold: 'Marked sold; transaction unconfirmed', withdrawn: 'Removed or unavailable; sale unconfirmed', unknown: 'Unknown' })[status] ?? 'Unknown';
const observedDate = (value: string) => Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleDateString() : 'date unavailable';
function money(price: number, currency: string) { try { return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(price); } catch { return `${price.toFixed(2)} ${currency}`; } }
</script>
<style scoped>
section { margin: 12px 0; } a { display: block; color: #89b4fa; padding: 8px 0; } small { display: block; color: #a6adc8; } p { font-size: 12px; }
</style>
