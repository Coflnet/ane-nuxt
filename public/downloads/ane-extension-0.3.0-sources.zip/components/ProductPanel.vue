<template>
  <aside v-if="visible" style="position:fixed;right:20px;bottom:20px;width:320px;max-height:70vh;overflow:auto;background:#181825;color:#cdd6f4;padding:16px;border-radius:12px;box-shadow:0 8px 32px #0008;font:13px/1.5 system-ui;z-index:2147483646">
    <button style="float:right;background:none;border:0;color:#cdd6f4;cursor:pointer" aria-label="Close Ane Deals" @click="visible = false">✕</button>
    <strong style="color:#cba6f7">Ane Deals</strong><p>{{ product.title }}</p>
    <p v-if="discovery.estimate">{{ priceEstimateLabel(discovery.estimate.source) }}: <strong>{{ money(discovery.estimate.value, discovery.estimate.currency) }}</strong><br><small>{{ discovery.estimate.sampleCount }} price samples{{ selectedProduct ? ' · Your selected product' : '' }}</small></p>
    <p v-else>No price estimate available yet.</p><small v-if="discovery.estimate?.source === 'active_asking_median'">Asking prices are not realized sale prices.</small>
    <p v-if="discovery.stored">Listing saved.</p>
    <p v-if="discovery.listing.browserCaptureUnverified">Browser capture: price and page details are unverified. Availability is checked separately by the server.</p>
    <a v-for="match in matches" :key="match.listingUrl" :href="match.listingUrl" target="_blank" rel="noopener noreferrer" style="display:block;color:#89b4fa;margin:8px 0;text-decoration:none"><strong>{{ money(match.price, match.currency) }}</strong> · {{ match.platform }}<br>{{ match.title }}</a>
    <p v-if="!matches.length">No similar listings available yet.</p>
    <SaleEvidence :discovery="discovery" />
    <small>Use the toolbar to select a reference price or refresh comparisons.</small>
  </aside>
</template>
<script setup lang="ts">
import { computed, ref } from 'vue';
import type { PageProduct } from '../utils/storeDetectors';
import { safeUrl } from '../utils/storeDetectors';
import { priceEstimateLabel, type DiscoveryResult } from '../utils/api';
import SaleEvidence from './SaleEvidence.vue';
const props = defineProps<{ product: PageProduct; discovery: DiscoveryResult; selectedProduct?: boolean }>();
const visible = ref(true);
const matches = computed(() => props.discovery.similarListings.filter(match => safeUrl(match.listingUrl)).slice(0, 5));
function money(value: number, currency: string) {
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(value); }
  catch { return `${value.toFixed(2)} ${currency}`; }
}
</script>
