<template>
  <main>
    <header><strong>Ane Deals</strong><a href="https://ane.deals/login" target="_blank" rel="noopener noreferrer">{{ authed ? 'Account' : 'Sign in' }} ↗</a></header>
    <p v-if="loading" role="status">{{ loading }}</p>
    <p v-if="error" class="error" role="alert">{{ error }}</p>
    <p v-if="!authed">Sign in on Ane Deals and keep that tab open, then <button :disabled="!!loading" @click="activate">retry</button>.</p>
    <section>
      <button :disabled="!canPickReference || !!loading" @click="pickReference">Select a reference price on this page</button>
      <template v-if="product">
        <h1>{{ product.title }}</h1><p class="muted">{{ product.platform }} · {{ money(product.price, product.currency) }}</p>
        <p v-if="discovery?.stored" class="notice">Listing saved{{ discovery.queued ? ' and queued for processing' : '' }}.</p>
        <p v-if="discovery?.listing.browserCaptureUnverified" class="muted">Browser capture: price and page details are unverified. Availability is checked separately by the server.</p>
        <div v-if="discovery?.estimate" class="estimate"><span>{{ estimateLabel }}</span><strong>{{ money(discovery.estimate.value, discovery.estimate.currency) }}</strong><small>{{ discovery.estimate.sampleCount }} price samples{{ selectedProduct ? ' · Your selected product' : '' }}</small></div>
        <p v-else-if="discovery">No estimate available yet. New listings may need processing. Product choices below can show existing price data.</p>
        <div v-if="discovery?.productCandidates.length && !discovery.productId">
          <p class="muted">Select the matching product to compare:</p><button v-for="candidate in discovery.productCandidates" :key="candidate.id" class="candidate" :disabled="!!loading" @click="discover(candidate.id)">{{ candidate.name }}</button>
        </div>
        <h2 v-if="discovery">Similar active listings</h2><p v-if="discovery?.estimate?.source === 'active_asking_median'" class="muted">Asking prices are not realized sale prices.</p>
        <a v-for="match in safeMatches" :key="match.listingUrl" class="match" :href="match.listingUrl" target="_blank" rel="noopener noreferrer"><strong>{{ money(match.price, match.currency) }}</strong><span>{{ match.title }}</span><small>{{ match.platform }}</small></a>
        <p v-if="discovery && !safeMatches.length" class="muted">No similar listings available yet.</p>
        <SaleEvidence v-if="discovery" :discovery="discovery" />
        <div class="actions"><button :disabled="!authed || !!loading" @click="discover()">Refresh data</button></div>
        <a :href="alertUrl" target="_blank" rel="noopener noreferrer">Create a listing alert ↗</a>
      </template>
      <p v-else-if="!loading">Open a supported marketplace's individual listing and press Ane Deals. Search and category pages are not collected.</p>
      <details><summary>Supported marketplaces</summary><p>{{ platformNames }}</p><p>Only the listing you open with this action is sent: URL, title, public description, price, image and condition.</p></details>
    </section>
  </main>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { discoverListing, priceEstimateLabel, type DiscoveryResult } from '../../utils/api';
import SaleEvidence from '../../components/SaleEvidence.vue';
import { marketplaces, safeUrl, type PageProduct } from '../../utils/storeDetectors';

const authed = ref(false);
const loading = ref('');
const error = ref('');
const product = ref<PageProduct | null>(null);
const discovery = ref<DiscoveryResult | null>(null);
const selectedProduct = ref(false);
const canPickReference = ref(false);
const estimateLabel = computed(() => priceEstimateLabel(discovery.value?.estimate?.source));
let listingTabId: number | undefined;
const platformNames = marketplaces.map(m => m.platform).join(', ');
const safeMatches = computed(() => discovery.value?.similarListings.filter(m => safeUrl(m.listingUrl)) ?? []);
const alertUrl = computed(() => 'https://ane.deals/filters/create?' + new URLSearchParams({ searchValue: product.value?.title ?? '', maxPrice: String(product.value?.price ?? '') }));
function money(value?: number | null, currency?: string) {
  if (value == null) return 'Price unavailable';
  if (!currency) return `${value.toFixed(2)} (currency unknown)`;
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(value); }
  catch { return `${value.toFixed(2)} ${currency}`; }
}
function failed(e: unknown) {
  error.value = e instanceof Error ? e.message : 'Request failed. Please retry.';
  if (error.value.includes('sign-in expired')) authed.value = false;
}

async function activate() {
  loading.value = 'Reading this listing…'; error.value = '';
  product.value = null; discovery.value = null; selectedProduct.value = false;
  try {
    const auth = await browser.runtime.sendMessage({ type: 'refreshAuth' }) as { authenticated: boolean; error?: string };
    authed.value = auth.authenticated;
    if (auth.error) error.value = auth.error;
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (tab?.id == null || !tab.url || !safeUrl(tab.url)) return;
    listingTabId = tab.id;
    const installed = await browser.scripting.executeScript({ target: { tabId: tab.id }, func: () => typeof (window as unknown as Record<string, unknown>).__ane_extract_listing__ === 'function' });
    if (!installed[0]?.result) await browser.scripting.executeScript({ target: { tabId: tab.id }, files: ['content-scripts/store-pages.js'] });
    const results = await browser.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const extract = (window as unknown as { __ane_extract_listing__?: () => unknown }).__ane_extract_listing__;
      return extract?.() ?? null;
    } });
    canPickReference.value = true;
    product.value = results[0]?.result as PageProduct | null;
    if (product.value && authed.value) await discover();
  } catch (e) { failed(e); }
  finally { loading.value = ''; }
}
async function pickReference() {
  if (listingTabId == null) return;
  try {
    await browser.tabs.sendMessage(listingTabId, { type: 'pickReference' });
    window.close();
  } catch (e) { failed(e); }
}
async function discover(productId?: string) {
  if (!product.value || !authed.value) return;
  loading.value = 'Saving listing and comparing prices…'; error.value = '';
  try {
    // No DOM nodes, account data or raw HTML leave the page.
    const { platform: _platform, listingId: _listingId, ...fields } = product.value;
    discovery.value = await discoverListing({ ...fields, productId });
    selectedProduct.value = !!productId;
    if (!product.value.currency && discovery.value.listing.currency) product.value.currency = discovery.value.listing.currency;
    if (!discovery.value.stored) throw new Error('The listing could not be saved. Please retry.');
    if (listingTabId != null) await browser.tabs.sendMessage(listingTabId, { type: 'showListing', product: product.value, discovery: discovery.value, selectedProduct: selectedProduct.value }).catch(() => {});
  } catch (e) { failed(e); }
  finally { loading.value = ''; }
}
onMounted(activate);
</script>

<style scoped>
main { padding: 16px; font-size: 13px; line-height: 1.5; }
header, .actions { display: flex; gap: 8px; align-items: center; justify-content: space-between; margin-bottom: 12px; }
header strong { font-size: 20px; color: #cba6f7; }
a { color: #89b4fa; text-decoration: none; overflow-wrap: anywhere; }
button { background: #313244; color: #cdd6f4; border: 1px solid #585b70; padding: 7px 10px; border-radius: 6px; cursor: pointer; }
button:focus-visible { background: #6c3d9e; }
button:disabled { opacity: .5; cursor: wait; }
h1 { font-size: 17px; margin: 8px 0; } h2 { font-size: 14px; margin: 12px 0 6px; }
p { margin: 8px 0; } .muted, small { color: #a6adc8; }
.error { color: #f38ba8; background: #311318; padding: 8px; border-radius: 6px; }
.notice { color: #a6e3a1; }
.estimate, .match { background: #181825; padding: 12px; border-radius: 8px; margin: 10px 0; }
.estimate span, .estimate strong, .estimate small, .match span, .match small { display: block; }
.estimate strong { font-size: 24px; color: #a6e3a1; }
.match { display: block; } .match strong { color: #a6e3a1; }
.candidate { width: 100%; text-align: left; margin: 3px 0; }
details { margin-top: 16px; color: #a6adc8; }
</style>
