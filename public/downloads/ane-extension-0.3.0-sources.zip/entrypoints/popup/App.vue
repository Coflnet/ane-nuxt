<template>
  <main>
    <header><strong>Ane Deals</strong><a href="https://ane.deals/login" target="_blank" rel="noopener noreferrer">{{ authed ? 'Account' : 'Sign in' }} ↗</a></header>
    <nav><button :class="{ selected: view === 'listing' }" @click="view = 'listing'">This listing</button><button :class="{ selected: view === 'flips' }"  :disabled="!!loading" @click="view = 'flips'; loadFlips()">My flips</button></nav>
    <p v-if="loading" role="status">{{ loading }}</p>
    <p v-if="error" class="error" role="alert">{{ error }}</p>
    <p v-if="notice" class="notice" role="status">{{ notice }}</p>
    <p v-if="!authed">Sign in on Ane Deals and keep that tab open, then <button :disabled="!!loading" @click="activate">retry</button>.</p>
    <section v-if="view === 'listing'">
      <button :disabled="!canPickReference || !!loading" @click="pickReference">Select a reference price on this page</button>
      <template v-if="product">
        <h1>{{ product.title }}</h1><p class="muted">{{ product.platform }} · {{ money(product.price, product.currency) }}</p>
        <p v-if="discovery?.stored" class="notice">Listing saved{{ discovery.queued ? ' and queued for processing' : '' }}.</p>
        <p v-if="discovery?.listing.browserCaptureUnverified" class="muted">Browser capture: price and page details are unverified. Availability is checked separately by the server.</p>
        <div v-if="discovery?.estimate" class="estimate"><span>{{ estimateLabel }}</span><strong>{{ money(discovery.estimate.value, discovery.estimate.currency) }}</strong><small>{{ discovery.estimate.sampleCount }} price samples{{ selectedProduct ? ' · Your selected product' : '' }}</small></div>
        <p v-else-if="discovery">No estimate available yet. New listings may need processing. Product choices below can show existing price data.</p>
        <div v-if="discovery?.productCandidates.length && !discovery.productId">
          <p class="muted">Select the matching product to compare:</p><button v-for="candidate in discovery.productCandidates" :key="candidate.id" class="candidate" :disabled="!!loading" @click="discover(candidate.id)">{{ candidate.name }}</button>
        </div>
        <h2 v-if="discovery">Similar active listings</h2><p v-if="discovery?.estimate?.source === 'active_asking_median'" class="muted">Asking prices are not realized sale prices.</p>
        <a v-for="match in safeMatches" :key="match.listingUrl" class="match" :href="match.listingUrl" target="_blank" rel="noopener noreferrer"><strong>{{ money(match.price, match.currency) }}</strong><span>{{ match.title }}</span><small>{{ match.platform }}</small></a>
        <p v-if="discovery && !safeMatches.length" class="muted">No similar listings available yet.</p>
        <SaleEvidence v-if="discovery" :discovery="discovery" />
        <div class="actions"><button :disabled="!authed || !!loading" @click="trackListing">Track this flip</button><button :disabled="!authed || !!loading" @click="discover()">Refresh data</button></div>
        <a :href="alertUrl" target="_blank" rel="noopener noreferrer">Create a listing alert ↗</a>
      </template>
      <p v-else-if="!loading">Open a supported marketplace's individual listing and press Ane Deals. Search and category pages are not collected.</p>
      <details><summary>Supported marketplaces</summary><p>{{ platformNames }}</p><p>Only the listing you open with this action is sent: URL, title, public description, price, image and condition.</p></details>
    </section>
    <section v-else>
      <div class="actions"><button :disabled="!authed || !!loading" @click="loadFlips()">Refresh flips</button><a href="https://ane.deals/flipper" target="_blank" rel="noopener noreferrer">Find opportunities ↗</a></div>
      <p v-if="authed && !flips.length && !loading">No tracked flips yet. Open a listing and choose “Track this flip”.</p>
      <p v-if="flips.length" class="muted">{{ flips.length }} flips loaded · recent updates among these records</p>
      <article v-for="flip in displayedFlips" :key="flip.id" class="flip">
        <a :href="safeUrl(flip.url)" target="_blank" rel="noopener noreferrer">{{ flip.title || flip.url }}</a><p>{{ flip.status }} · {{ flip.platform }}</p>
        <p v-if="flip.profit != null">Net profit: <strong>{{ money(flip.profit, flip.currency) }}</strong></p>
        <p v-else-if="flip.purchasePrice != null && flip.targetPrice != null">Target profit: {{ money(flip.targetPrice - flip.purchasePrice - flip.fees - flip.shippingCost, flip.currency) }}</p>
        <div class="actions"><button :disabled="!!loading" @click="editFlip(flip)">Edit</button><button :disabled="!!loading" @click="removeFlip(flip)">Delete</button></div>
      </article>
      <button v-if="nextFlipCursor" :disabled="!!loading" @click="loadFlips(true)">Load more flips</button>
    </section>
    <form v-if="draft" @submit.prevent="saveFlip">
      <h2>{{ editingId ? 'Edit flip' : 'Track this flip' }}</h2>
      <label>Title<input v-model="draft.title" maxlength="300" /></label>
      <label>Status<select v-model="draft.status"><option v-for="status in statuses" :key="status" :value="status">{{ status }}</option></select></label>
      <div class="fields"><label>Purchase price<input v-model="draft.purchasePrice" type="number" min="0" step="0.01" /></label><label>Target price<input v-model="draft.targetPrice" type="number" min="0" step="0.01" /></label><label>Sale price<input v-model="draft.salePrice" type="number" min="0" step="0.01" /></label><label>Fees<input v-model="draft.fees" type="number" min="0" step="0.01" required /></label><label>Shipping cost<input v-model="draft.shippingCost" type="number" min="0" step="0.01" required /></label><label>Currency<input v-model="draft.currency" pattern="[A-Za-z]{3}" maxlength="3" placeholder="EUR" required /></label></div>
      <label>Notes<textarea v-model="draft.notes" maxlength="4000" rows="3" /></label>
      <p v-if="draft.status === 'sold' && draft.salePrice == null" class="muted">Enter the sale price to calculate realized profit.</p>
      <div class="actions"><button :disabled="!!loading" type="submit">Save flip</button><button type="button" @click="draft = null">Cancel</button></div>
    </form>
  </main>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { discoverListing, getUserFlips, saveUserFlip, deleteUserFlip, priceEstimateLabel, type DiscoveryResult, type FlipInput, type UserFlip, type FlipStatus } from '../../utils/api';
import SaleEvidence from '../../components/SaleEvidence.vue';
import { marketplaces, safeUrl, type PageProduct } from '../../utils/storeDetectors';

const view = ref<'listing' | 'flips'>('listing');
const authed = ref(false);
const loading = ref('');
const error = ref('');
const notice = ref('');
const product = ref<PageProduct | null>(null);
const discovery = ref<DiscoveryResult | null>(null);
const selectedProduct = ref(false);
const canPickReference = ref(false);
const estimateLabel = computed(() => priceEstimateLabel(discovery.value?.estimate?.source));
const flips = ref<UserFlip[]>([]);
const nextFlipCursor = ref<string | null>(null);
let flipPageLoaded = false;
const displayedFlips = computed(() => [...flips.value].sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)));
function mergeFlips(items: UserFlip[]) { return [...new Map(items.map(flip => [flip.id, flip])).values()]; }
const draft = ref<FlipInput | null>(null);
const editingId = ref<string>();
let listingTabId: number | undefined;
const statuses: FlipStatus[] = ['watching', 'bought', 'listed', 'sold', 'archived'];
const platformNames = marketplaces.map(m => m.platform).join(', ');
const safeMatches = computed(() => discovery.value?.similarListings.filter(m => safeUrl(m.listingUrl)) ?? []);
const alertUrl = computed(() => 'https://ane.deals/filters/create?' + new URLSearchParams({ searchValue: product.value?.title ?? '', maxPrice: String(product.value?.price ?? '') }));
function money(value?: number | null, currency?: string) {
  if (value == null) return 'Price unavailable';
  if (!currency) return `${value.toFixed(2)} (currency unknown)`;
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(value); }
  catch { return `${value.toFixed(2)} ${currency}`; }
}
function failed(e: unknown) {
  error.value = e instanceof Error ? e.message : 'Request failed. Please retry.';
  if (error.value.includes('sign-in expired')) authed.value = false;
}

async function activate() {
  loading.value = 'Reading this listing…'; error.value = ''; notice.value = '';
  product.value = null; discovery.value = null; selectedProduct.value = false;
  try {
    const auth = await browser.runtime.sendMessage({ type: 'refreshAuth' }) as { authenticated: boolean; error?: string };
    authed.value = auth.authenticated;
    if (auth.error) error.value = auth.error;
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (tab?.id == null || !tab.url || !safeUrl(tab.url)) return;
    listingTabId = tab.id;
    const installed = await browser.scripting.executeScript({ target: { tabId: tab.id }, func: () => typeof (window as unknown as Record<string, unknown>).__ane_extract_listing__ === 'function' });
    if (!installed[0]?.result) await browser.scripting.executeScript({ target: { tabId: tab.id }, files: ['content-scripts/store-pages.js'] });
    const results = await browser.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const extract = (window as unknown as { __ane_extract_listing__?: () => unknown }).__ane_extract_listing__;
      return extract?.() ?? null;
    } });
    canPickReference.value = true;
    product.value = results[0]?.result as PageProduct | null;
    if (product.value && authed.value) await discover();
  } catch (e) { failed(e); }
  finally { loading.value = ''; }
}
async function pickReference() {
  if (listingTabId == null) return;
  try {
    await browser.tabs.sendMessage(listingTabId, { type: 'pickReference' });
    window.close();
  } catch (e) { failed(e); }
}
async function discover(productId?: string) {
  if (!product.value || !authed.value) return;
  loading.value = 'Saving listing and comparing prices…'; error.value = '';
  try {
    // No DOM nodes, account data or raw HTML leave the page.
    const { platform: _platform, listingId: _listingId, ...fields } = product.value;
    discovery.value = await discoverListing({ ...fields, productId });
    selectedProduct.value = !!productId;
    if (!product.value.currency && discovery.value.listing.currency) product.value.currency = discovery.value.listing.currency;
    if (!discovery.value.stored) throw new Error('The listing could not be saved. Please retry.');
    if (listingTabId != null) await browser.tabs.sendMessage(listingTabId, { type: 'showListing', product: product.value, discovery: discovery.value, selectedProduct: selectedProduct.value }).catch(() => {});
  } catch (e) { failed(e); }
  finally { loading.value = ''; }
}
async function loadFlips(append = false) {
  if (!authed.value || loading.value) return;
  loading.value = 'Loading your flips…'; error.value = '';
  try {
    const page = await getUserFlips(append ? nextFlipCursor.value : null);
    flips.value = mergeFlips([...(append ? flips.value : []), ...page.items]);
    nextFlipCursor.value = page.nextCursor; flipPageLoaded = true;
  }
  catch (e) { failed(e); }
  finally { loading.value = ''; }
}
function trackListing() {
  if (!product.value) return;
  editingId.value = undefined;
  const estimate = discovery.value?.estimate;
  draft.value = { url: product.value.url, title: product.value.title, purchasePrice: product.value.price ?? null, targetPrice: estimate && estimate.currency === product.value.currency ? estimate.value : null, salePrice: null, fees: 0, shippingCost: 0, currency: product.value.currency ?? '', status: 'watching', notes: '' };
}
function editFlip(flip: UserFlip) { editingId.value = flip.id; draft.value = { ...flip }; }
function numberField(value: unknown, optional = false): number | null {
  if (optional && (value == null || value === '')) return null;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) throw new Error('Prices and costs must be nonnegative numbers.');
  return parsed;
}
async function saveFlip() {
  if (!draft.value) return;
  loading.value = 'Saving flip…'; error.value = ''; notice.value = '';
  try {
    const value = draft.value;
    const saved = await saveUserFlip({ url: value.url, title: value.title, status: value.status, notes: value.notes, currency: value.currency.toUpperCase(), purchasePrice: numberField(value.purchasePrice, true), targetPrice: numberField(value.targetPrice, true), salePrice: numberField(value.salePrice, true), fees: numberField(value.fees)!, shippingCost: numberField(value.shippingCost)! }, editingId.value);
    draft.value = null; notice.value = 'Flip saved.'; view.value = 'flips';
    if (!flipPageLoaded) {
      const page = await getUserFlips();
      flips.value = page.items; nextFlipCursor.value = page.nextCursor; flipPageLoaded = true;
    }
    flips.value = mergeFlips([...flips.value, saved]);
  } catch (e) { failed(e); }
  finally { loading.value = ''; }
}
async function removeFlip(flip: UserFlip) {
  if (!window.confirm(`Delete “${flip.title || 'this flip'}” from your tracker?`)) return;
  loading.value = 'Deleting flip…'; error.value = '';
  try { await deleteUserFlip(flip.id); flips.value = flips.value.filter(item => item.id !== flip.id); notice.value = 'Flip deleted.'; }
  catch (e) { failed(e); }
  finally { loading.value = ''; }
}
onMounted(activate);
</script>

<style scoped>
main { padding: 16px; font-size: 13px; line-height: 1.5; }
header, nav, .actions { display: flex; gap: 8px; align-items: center; justify-content: space-between; margin-bottom: 12px; }
header strong { font-size: 20px; color: #cba6f7; }
a { color: #89b4fa; text-decoration: none; overflow-wrap: anywhere; }
button { background: #313244; color: #cdd6f4; border: 1px solid #585b70; padding: 7px 10px; border-radius: 6px; cursor: pointer; }
button.selected, button[type=submit] { background: #6c3d9e; }
button:disabled { opacity: .5; cursor: wait; }
h1 { font-size: 17px; margin: 8px 0; } h2 { font-size: 14px; margin: 12px 0 6px; }
p { margin: 8px 0; } .muted, small { color: #a6adc8; }
.error { color: #f38ba8; background: #311318; padding: 8px; border-radius: 6px; }
.notice { color: #a6e3a1; }
.estimate, .flip, .match, form { background: #181825; padding: 12px; border-radius: 8px; margin: 10px 0; }
.estimate span, .estimate strong, .estimate small, .match span, .match small { display: block; }
.estimate strong { font-size: 24px; color: #a6e3a1; }
.match { display: block; } .match strong { color: #a6e3a1; }
.candidate { width: 100%; text-align: left; margin: 3px 0; }
label { display: block; margin: 6px 0; } input, select, textarea { display: block; width: 100%; padding: 7px; background: #313244; color: #cdd6f4; border: 1px solid #585b70; border-radius: 5px; }
.fields { display: grid; grid-template-columns: 1fr 1fr; gap: 0 10px; }
details { margin-top: 16px; color: #a6adc8; }
</style>
