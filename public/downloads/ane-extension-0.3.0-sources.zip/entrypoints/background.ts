import { DEFAULT_BASE } from '../utils/api';

export default defineBackground(() => {
  // Remove legacy crowd-scrape alarms when upgrading. This extension collects only on action.
  const alarms = (browser as unknown as { alarms?: { clearAll(): Promise<boolean> } }).alarms;
  alarms?.clearAll().catch(() => {});
  // On Chrome, also deny extension content scripts access to stored credentials.
  const storage = browser.storage.local as typeof browser.storage.local & { setAccessLevel?: (options: { accessLevel: string }) => Promise<void> };
  storage.setAccessLevel?.({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});

  browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Auth operations are available only to our own extension pages.
    if (sender.id !== browser.runtime.id || sender.url !== browser.runtime.getURL('/popup.html')) { sendResponse({ authenticated: false }); return true; }
    if ((message as { type?: string })?.type !== 'refreshAuth') { sendResponse({ authenticated: false }); return true; }
    refreshAuth().then(sendResponse).catch(async () => {
      await browser.storage.local.remove(['aneToken', 'tokenSavedAt']);
      sendResponse({ authenticated: false, error: 'Sign-in could not be refreshed. Open Ane Deals and retry.' });
    });
    return true;
  });
});

async function refreshAuth(): Promise<{ authenticated: boolean; error?: string }> {
  const tabs = await browser.tabs.query({ url: ['https://ane.deals/*', 'https://ane.coflnet.com/*'] });
  if (!tabs.length) {
    const saved = await browser.storage.local.get(['aneToken', 'tokenSavedAt']);
    if (saved.aneToken && Date.now() - Number(saved.tokenSavedAt) < 55 * 60_000) return { authenticated: true };
    await browser.storage.local.remove(['aneToken', 'tokenSavedAt']);
    return { authenticated: false };
  }
  for (const tab of tabs) {
    if (tab.id == null) continue;
    const results = await browser.scripting.executeScript({ target: { tabId: tab.id }, func: extractFirebaseToken });
    const token = results[0]?.result;
    if (!token) continue;
    const response = await fetch(`${DEFAULT_BASE}/api/auth/firebase`, {
      method: 'POST', signal: AbortSignal.timeout(15_000), headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ authToken: token }),
    });
    if (!response.ok) throw new Error('Authentication exchange failed');
    const data = await response.json() as { authToken?: string };
    if (!data.authToken) throw new Error('Missing Ane auth token');
    await browser.storage.local.set({ aneToken: data.authToken, tokenSavedAt: Date.now() });
    return { authenticated: true };
  }
  await browser.storage.local.remove(['aneToken', 'tokenSavedAt']);
  return { authenticated: false };
}

// This runs in the isolated world on an exact trusted Ane origin, never a marketplace.
function extractFirebaseToken(): Promise<string | null> {
  return new Promise(resolve => {
    const req = indexedDB.open('firebaseLocalStorageDb');
    req.onerror = () => resolve(null);
    req.onsuccess = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('firebaseLocalStorage')) { db.close(); resolve(null); return; }
      const tx = db.transaction('firebaseLocalStorage', 'readonly');
      const all = tx.objectStore('firebaseLocalStorage').getAll();
      all.onerror = () => { db.close(); resolve(null); };
      all.onsuccess = () => {
        db.close();
        const entries = all.result as Array<{ fbase_key?: string; value?: { isAnonymous?: boolean; stsTokenManager?: { accessToken?: string; expirationTime?: number } } }>;
        const user = entries.find(entry => entry.fbase_key?.includes('authUser'))?.value;
        const manager = user?.stsTokenManager;
        resolve(!user?.isAnonymous && Number(manager?.expirationTime) > Date.now() ? manager?.accessToken ?? null : null);
      };
    };
  });
}
