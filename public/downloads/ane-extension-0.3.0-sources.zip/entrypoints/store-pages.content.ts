import { createApp, type App } from 'vue';
import type { DiscoveryResult } from '../utils/api';
import type { PageProduct } from '../utils/storeDetectors';
import { detectStorePage } from '../utils/storeDetectors';
import ProductPanel from '../components/ProductPanel.vue';
import { startReferencePicker } from '../utils/referencePicker';

// Bundled by WXT, injected by the popup only with the action's activeTab grant.
export default defineContentScript({
  matches: [], registration: 'runtime',
  main(ctx) {
    const state = window as unknown as Record<string, unknown>;
    state.__ane_extract_listing__ = detectStorePage;
    // Repeated action presses reuse the same isolated-world listener.
    if (state.__ane_panel_ready__) return;
    state.__ane_panel_ready__ = true;
    let app: App | undefined;
    let host: HTMLElement | undefined;
    let stopPicking: (() => void) | undefined;
    const listener = (rawMessage: unknown, sender: { id?: string; url?: string }) => {
      const message = rawMessage as { type?: string; product?: PageProduct; discovery?: DiscoveryResult; selectedProduct?: boolean };
      if (sender.id !== browser.runtime.id || sender.url !== browser.runtime.getURL('/popup.html')) return;
      if (message?.type === 'pickReference') { stopPicking?.(); stopPicking = startReferencePicker(); return; }
      if (message?.type !== 'showListing') return;
      // Ignore a result if the user navigated while its request was running.
      if (detectStorePage()?.url !== message.product?.url) return;
      app?.unmount(); host?.remove();
      host = document.createElement('div');
      host.id = 'ane-extension-panel';
      host.setAttribute('aria-label', 'Ane Deals price comparison');
      const shadow = host.attachShadow({ mode: 'closed' });
      const mount = document.createElement('div'); shadow.appendChild(mount);
      document.body.appendChild(host);
      app = createApp(ProductPanel, { product: message.product, discovery: message.discovery, selectedProduct: message.selectedProduct });
      app.mount(mount);
    };
    browser.runtime.onMessage.addListener(listener);
    const clearPanel = () => { stopPicking?.(); stopPicking = undefined; app?.unmount(); host?.remove(); app = undefined; host = undefined; };
    ctx.addEventListener(window, 'wxt:locationchange', clearPanel);
    ctx.onInvalidated(() => { clearPanel(); browser.runtime.onMessage.removeListener(listener); delete state.__ane_panel_ready__; delete state.__ane_extract_listing__; });
  },
});
