import assert from 'node:assert/strict';
import { mkdtemp, cp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { chromium } from 'playwright';

const temp = await mkdtemp(join(tmpdir(), 'ane-extension-smoke-'));
const extension = join(temp, 'extension');
await cp(resolve('.output/chrome-mv3'), extension, { recursive: true });
const manifest = JSON.parse(await readFile(join(extension, 'manifest.json'), 'utf8'));
assert.deepEqual(manifest.permissions.slice().sort(), ['activeTab', 'scripting', 'storage']);
assert.deepEqual(manifest.host_permissions, ['https://ane.deals/*', 'https://ane.coflnet.com/*']);
assert.deepEqual(manifest.content_scripts, []);
// Chrome automation does not synthesize toolbar gestures' activeTab grants.
// Grant only this fixture origin in the temporary copy; shipped manifest is checked above.
manifest.host_permissions.push('https://www.vinted.de/*');
await writeFile(join(extension, 'manifest.json'), JSON.stringify(manifest));
let context;
let debugPopup;
try {
  context = await chromium.launchPersistentContext(join(temp, 'profile'), {
    channel: 'chromium', executablePath: process.env.CHROMIUM_PATH, headless: true,
    args: [`--disable-extensions-except=${extension}`, `--load-extension=${extension}`, '--no-sandbox'],
    ignoreDefaultArgs: ['--disable-extensions'],
  });
  const worker = context.serviceWorkers()[0] ?? await context.waitForEvent('serviceworker');
  const calls = [];
  let apiFailure = false;
  let estimateSource = 'sold_reference_asking_median';
  let delayedResponse;
  let releaseResponse;
  const listingUrl = 'https://www.vinted.de/items/123456-camera';
  await context.route('https://www.vinted.de/**', route => route.fulfill({ contentType: 'text/html', body: `<html lang="de"><meta charset="utf-8"><h1>Camera &lt;safe&gt;</h1><span id="reference-price">100,00 €</span><span id="reference-shipping">5,00 €</span><input id="private-input" value="Private account data"><script type="application/ld+json">${JSON.stringify({ '@type': 'Product', url: listingUrl, name: 'Camera <safe>', datePosted: '2026-10-03T12:00:00Z', offers: { price: '100.00', priceCurrency: 'EUR', availability: 'https://schema.org/InStock' } })}</script></html>` }));
  await context.route('https://ane.coflnet.com/api/**', async route => {
    const req = route.request(); const url = new URL(req.url());
    calls.push({ path: url.pathname, method: req.method(), body: req.postDataJSON(), authorization: req.headers().authorization });
    if (url.pathname === '/api/auth/firebase') {
      assert.equal(req.postDataJSON().authToken, 'firebase-smoke-token');
      return route.fulfill({ json: { authToken: 'smoke-ane-token' } });
    }
    assert.equal(req.headers().authorization, 'Bearer smoke-ane-token');
    if (apiFailure === 'timeout') { await new Promise(resolve => setTimeout(resolve, 16_000)); return route.fulfill({ status: 503 }).catch(() => {}); }
    if (typeof apiFailure === 'number') return route.fulfill({ status: apiFailure, json: { error: 'test failure' } });
    if (apiFailure === 'delayed') await delayedResponse;
    if (url.pathname === '/api/extension/discover') {
      const body = req.postDataJSON(); assert.equal(body.url, listingUrl); assert.equal(body.currency, 'EUR'); assert.equal(body.availability, 'available');
      assert.equal(body.createdAt, '2026-10-03T12:00:00.000Z');
      assert.equal(body.platform, undefined); assert.equal(body.listingId, undefined);
      return route.fulfill({ json: { listing: { id: '123456', platform: 'Vinted', url: listingUrl, title: body.title, price: 100, currency: 'EUR', imageUrls: [], browserCaptureUnverified: true }, stored: true, queued: true, productId: 'camera', estimate: { value: 180, currency: 'EUR', source: estimateSource, sampleCount: 12 }, productCandidates: [], saleStatus: { status: 'withdrawn', firstUnavailableAt: '2026-10-04T12:00:00Z' }, saleReferences: [{ listingId: 'sold-1', platform: 'Ebay', url: 'https://www.ebay.de/itm/123987', title: 'Listing marked sold', price: 180, currency: 'EUR', status: 'reported_sold', evidence: 'sold_out_marker', observedAt: '2026-10-04T12:00:00Z' }, { listingId: 'withdrawn-1', platform: 'Ebay', url: 'https://www.ebay.de/itm/123986', title: 'Withdrawn listing', price: 155, currency: 'EUR', status: 'withdrawn', evidence: 'sale_unconfirmed', observedAt: '2026-10-04T12:00:00Z' }, { listingId: 'inferred-1', platform: 'OLX', url: 'https://www.olx.pl/d/oferta/camera-IDabc12.html', title: 'Inferred sale listing', price: 170, currency: 'EUR', status: 'inferred_sold', evidence: 'inferred_disappearance_2_48h', ageBasis: 'first_seen', observedAt: '2026-10-04T12:00:00Z' }, { listingId: 'inferred-posted', platform: 'Marktplaats', url: 'https://www.marktplaats.nl/v/audio/m123-test-camera', title: 'Publisher age inferred reference', price: 170, currency: 'EUR', status: 'inferred_sold', evidence: 'inferred_disappearance_2_48h', ageBasis: 'listing_created_at', observedAt: '2026-10-04T12:00:00Z' }, { listingId: 'unsafe', platform: 'Ebay', url: 'javascript:alert(1)', title: 'Unsafe sale reference', price: 0, currency: 'EUR', status: 'withdrawn', observedAt: '2026-10-04T12:00:00Z' }], similarListings: [{ listingUrl: 'https://www.ebay.de/itm/987654', title: 'Comparable camera', price: 175, currency: 'EUR', platform: 'Ebay', postedAt: new Date().toISOString() }, { listingUrl: 'javascript:alert(1)', title: 'Unsafe listing', price: 0, currency: 'EUR', platform: 'Ebay' }] } });
    }
    throw new Error(`Unexpected API call: ${req.method()} ${url.pathname}`);
  });
  const marketplace = context.pages()[0] ?? await context.newPage();
  await marketplace.goto(listingUrl);
  assert.equal(calls.length, 0, 'Visiting a marketplace must not collect anything');
  const extensionId = new URL(worker.url()).hostname;
  const openPopup = async () => {
    // Load the actual built popup in an extension tab. Browser automation cannot inspect
    // Chrome's toolbar popup target, so redirect its active-tab lookup to our fixture.
    const page = await context.newPage();
    debugPopup = page;
    page.on('pageerror', error => console.error('Popup runtime error:', error.message));
    page.setDefaultTimeout(10_000);
    await page.addInitScript(() => {
      const original = chrome.tabs.query.bind(chrome.tabs);
      chrome.tabs.query = (query, ...rest) => original(query.active && query.currentWindow ? { url: 'https://www.vinted.de/*' } : query, ...rest);
    });
    await page.goto(`chrome-extension://${extensionId}/popup.html`);
    return page;
  };
  let popup = await openPopup();
  await popup.getByText('Sign in on Ane Deals and keep that tab open').waitFor();
  assert.equal(calls.length, 0, 'Unauthenticated action must not store a listing');
  await popup.close();
  await context.route('https://ane.deals/**', route => route.fulfill({ contentType: 'text/html', body: '<h1>Ane authentication fixture</h1>' }));
  const authPage = await context.newPage();
  await authPage.goto('https://ane.deals/login');
  await authPage.evaluate(() => new Promise((resolve, reject) => {
    const request = indexedDB.open('firebaseLocalStorageDb');
    request.onupgradeneeded = () => request.result.createObjectStore('firebaseLocalStorage', { keyPath: 'fbase_key' });
    request.onerror = reject;
    request.onsuccess = () => {
      const db = request.result;
      const transaction = db.transaction('firebaseLocalStorage', 'readwrite');
      transaction.objectStore('firebaseLocalStorage').put({ fbase_key: 'firebase:authUser:fixture', value: { isAnonymous: false, stsTokenManager: { accessToken: 'firebase-smoke-token', expirationTime: Date.now() + 60_000 } } });
      transaction.oncomplete = () => { db.close(); resolve(); };
      transaction.onerror = reject;
    };
  }));
  popup = await openPopup();
  await popup.getByText('Last asking prices of listings marked sold').waitFor();
  await popup.getByText('Browser capture: price and page details are unverified. Availability is checked separately by the server.').waitFor();
  await popup.getByText('Advertised prices, not confirmed transaction prices. Disappearance within 2–48 hours is an inferred sale; other removals are excluded from sale estimates.').waitFor();
  await popup.getByText('Removed or unavailable; sale unconfirmed', { exact: false }).first().waitFor();
  assert.equal(await popup.getByText('Unsafe sale reference').count(), 0);
  await popup.getByText('Inferred sale; disappeared within 2–48 hours since first seen', { exact: false }).waitFor();
  await popup.getByText('Inferred sale; disappeared within 2–48 hours since listing posted', { exact: false }).waitFor();
  assert.equal(await popup.getByText('Comparable camera').count(), 1);
  assert.equal(await popup.getByText('Unsafe listing').count(), 0);
  assert.equal(await popup.getByRole('heading', { name: 'Camera <safe>' }).count(), 1);
  const shadowCount = await worker.evaluate(async () => {
    const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.de/*' });
    const result = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'ISOLATED', func: () => !!window.__ane_panel_ready__ });
    return result[0].result;
  });
  assert.equal(shadowCount, true);
  await marketplace.locator('#ane-extension-panel').waitFor({ state: 'attached' });
  assert.equal(await marketplace.evaluate(() => document.querySelector('#ane-extension-panel').shadowRoot), null, 'Comparison panel uses a closed shadow root');
  estimateSource = 'inferred_sale_asking_median';
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByText('Last asking prices of reported or inferred sales').waitFor();
  estimateSource = 'sold_reference_asking_median';
  apiFailure = 503;
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByRole('alert').filter({ hasText: '503' }).waitFor();
  apiFailure = 429;
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByRole('alert').filter({ hasText: '429' }).waitFor();
  apiFailure = 'timeout';
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByRole('alert').filter({ hasText: 'timed out' }).waitFor({ timeout: 20_000 });
  apiFailure = false;
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByText('Saving listing and comparing prices…').waitFor({ state: 'hidden' });
  assert.equal(await popup.getByRole('alert').count(), 0, 'A subsequent success clears the previous request error');
  assert.equal(await marketplace.locator('#ane-extension-panel').count(), 1, 'Repeated comparisons replace the panel');
  await popup.close();
  popup = await openPopup();
  await popup.getByText('Last asking prices of listings marked sold').waitFor();
  assert.equal(await marketplace.locator('#ane-extension-panel').count(), 1, 'Repeated action uses one content context');
  assert.equal(await marketplace.evaluate(() => typeof window.__ane_extract_listing__), 'undefined', 'Page MAIN world cannot access extension extraction hooks');
  apiFailure = 401;
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByText('Sign in on Ane Deals and keep that tab open').waitFor();
  assert.equal(await worker.evaluate(async () => !!(await chrome.storage.local.get('aneToken')).aneToken), false, 'Expired API auth is removed');
  apiFailure = false;
  await popup.getByRole('button', { name: 'retry', exact: true }).click();
  await popup.getByText('Saving listing and comparing prices…').waitFor({ state: 'hidden' });
  await popup.getByText('Last asking prices of listings marked sold').waitFor();
  apiFailure = 'delayed';
  delayedResponse = new Promise(resolve => { releaseResponse = resolve; });
  await popup.getByRole('button', { name: 'Refresh data', exact: true }).click();
  await popup.getByText('Saving listing and comparing prices…').waitFor();
  await marketplace.evaluate(() => history.pushState(null, '', '/items/999999-another-listing'));
  await marketplace.locator('#ane-extension-panel').waitFor({ state: 'detached' });
  releaseResponse();
  await popup.getByText('Saving listing and comparing prices…').waitFor({ state: 'hidden' });
  assert.equal(await marketplace.locator('#ane-extension-panel').count(), 0, 'Late response must not render on a different listing');
  apiFailure = false;
  assert.ok(calls.some(call => call.path === '/api/auth/firebase'), 'Firebase tokens are exchanged for Ane auth tokens');
  assert.equal(await popup.getByRole('button', { name: 'Track this flip', exact: true }).count(), 0);
  assert.equal(await popup.getByRole('button', { name: 'My flips', exact: true }).count(), 0);
  await marketplace.goto(listingUrl);
  // Open only this test picker's shadow root so Playwright can assert its confirmation UI.
  await worker.evaluate(async () => {
    const [tab] = await chrome.tabs.query({ url: 'https://www.vinted.de/*' });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const attach = Element.prototype.attachShadow;
      Element.prototype.attachShadow = function(options) { return attach.call(this, this.id === 'ane-reference-picker' ? { mode: 'open' } : options); };
    } });
  });
  popup = await openPopup();
  await popup.getByText('Last asking prices of listings marked sold').waitFor();
  const closed = popup.waitForEvent('close');
  await popup.getByRole('button', { name: 'Select a reference price on this page' }).click();
  await closed;
  const callsBeforePick = calls.length;
  await marketplace.locator('#reference-price').click();
  await marketplace.locator('#reference-shipping').click({ modifiers: ['Shift'] });
  await marketplace.getByRole('status').filter({ hasText: 'Selected 2 prices' }).waitFor();
  const referenceLink = new URL(await marketplace.getByRole('link', { name: 'Create alert on Ane Deals' }).getAttribute('href'));
  assert.equal(referenceLink.searchParams.get('referenceSelector'), "//*[@id='reference-price']");
  assert.equal(referenceLink.searchParams.get('referenceAdditionalSelectors'), "//*[@id='reference-shipping']");
  assert.equal(referenceLink.searchParams.get('referencePrice'), '105');
  assert.equal(referenceLink.searchParams.get('referenceCurrency'), 'EUR');
  assert.equal(referenceLink.searchParams.get('referenceUrl'), listingUrl);
  assert.equal(referenceLink.href.includes('Private'), false);
  assert.equal(calls.length, callsBeforePick, 'Picking prices must not upload page HTML or account data');
  if (process.env.NUXT_TEST_URL && process.env.REFERENCE_TEST_URL) {
    // Exercise the real built Nuxt form against a local Core preview-service fixture.
    // The extension keeps its production HTTPS URLs; only this test proxies them locally.
    await context.route('https://ane.deals/**', async route => {
      const requested = new URL(route.request().url());
      const target = new URL(requested.pathname + requested.search, process.env.NUXT_TEST_URL);
      await route.fulfill({ response: await route.fetch({ url: target.href }) });
    });
    await context.route('https://*.googleapis.com/**', route => route.fulfill({ status: 400, json: { error: { message: 'TEST_AUTH_DISABLED' } } }));
    await context.route('https://ane.coflnet.com/api/**', route => route.fulfill({ json: [], headers: { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*' } }));
    const verificationRequests = [];
    await context.route('https://ane.coflnet.com/api/reference-listings/preview', async route => {
      const cors = { 'access-control-allow-origin': 'https://ane.deals', 'access-control-allow-headers': 'content-type', 'access-control-allow-methods': 'POST, OPTIONS' };
      if (route.request().method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
      verificationRequests.push(route.request().postDataJSON());
      const response = await route.fetch({ url: new URL('/api/reference-listings/preview', process.env.REFERENCE_TEST_URL).href });
      await route.fulfill({ response, headers: { ...response.headers(), ...cors } });
    });
    const form = await context.newPage();
    await form.goto(referenceLink.href);
    await form.getByText('Selected in your browser.', { exact: false }).waitFor();
    assert.equal(await form.getByLabel('Max Price Input', { exact: true }).inputValue(), '105');
    await form.getByRole('button', { name: 'Preview reference', exact: true }).click();
    await form.getByRole('button', { name: 'Set max price from reference', exact: true }).waitFor({ state: 'visible' });
    await form.getByRole('button', { name: 'Set max price from reference', exact: true }).click();
    assert.equal(verificationRequests[0].selectedSelector, referenceLink.searchParams.get('referenceSelector'));
    assert.deepEqual(verificationRequests[0].additionalSelectors, [referenceLink.searchParams.get('referenceAdditionalSelectors')]);
    assert.equal(await form.getByLabel('Max Price Input', { exact: true }).inputValue(), '105');
    await form.getByRole('button', { name: 'Clear extras', exact: true }).last().click();
    assert.equal(await form.getByLabel('Max Price Input', { exact: true }).inputValue(), '100', 'Removing the last extra restores the base price');
    const privateLink = new URL(referenceLink);
    privateLink.searchParams.set('referenceUrl', 'https://www.vinted.de/private');
    await form.goto(privateLink.href);
    await form.getByLabel('Max Price Input', { exact: true }).waitFor();
    await form.getByRole('button', { name: 'Preview reference', exact: true }).click();
    await form.getByText('The selected price could not be found on the public page.', { exact: false }).waitFor();
    assert.equal(await form.getByLabel('Max Price Input', { exact: true }).inputValue(), '105', 'A browser-only selector retains the captured threshold');
    assert.equal(await form.getByRole('button', { name: 'Set max price from reference', exact: true }).isDisabled(), true);
    await form.screenshot({ path: '/tmp/ane-filter-reference-flow.png', fullPage: true });
    await form.close();
    console.log('Integration passed: extension selection → actual Nuxt prefill → Core public-selector verification; extra removal and inaccessible-selection preservation.');
  }
  await marketplace.keyboard.press('Escape');
  await marketplace.locator('#ane-reference-picker').waitFor({ state: 'detached' });
  console.log('Browser smoke passed: action extraction, safe comparison links, on-page panel, unauthenticated/error handling 429/503/timeout recovery and repeated activation/navigation and explicit reference-price selection with shipping, safe create-alert prefill and cancellation.');
} catch (error) {
  for (const page of context?.pages() ?? [])
    if (page.url().startsWith('https://www.vinted.de/')) console.error('Picker fixture state:', await page.locator('#ane-reference-picker').evaluateAll(nodes => nodes.map(node => ({ open: !!node.shadowRoot, text: node.shadowRoot?.textContent }))));
  if (debugPopup && !debugPopup.isClosed()) console.error('Popup state:', await debugPopup.locator('body').innerText());
  throw error;
} finally {
  await context?.close();
  await rm(temp, { recursive: true, force: true });
}
