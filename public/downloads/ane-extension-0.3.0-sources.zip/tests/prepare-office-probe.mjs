// Local normal-Chrome test only. The shipping extension and sibling OfficeScraper remain unchanged.
import assert from 'node:assert/strict';
import { cp, mkdir, readFile, writeFile, mkdtemp } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { tmpdir } from 'node:os';
const output = process.argv[2] ? resolve(process.argv[2]) : await mkdtemp(join(tmpdir(), 'ane-office-probe-'));
const office = resolve(process.env.ANE_OFFICE_SCRAPER_PATH || resolve(import.meta.dirname, '../../../Cait/OfficeScraper'));
const build = resolve(import.meta.dirname, '../.output/chrome-mv3');
await mkdir(output, { recursive: true });
await cp(join(office, 'extension'), join(output, 'office-bridge'), { recursive: true });
await cp(build, join(output, 'ane-extension'), { recursive: true });
let source = await readFile(join(output, 'office-bridge/background.js'), 'utf8');
if (process.env.ANE_OFFICE_SCRAPER_PATH) assert.ok(source.includes('readyCard'), 'Selected Office bridge lacks Wallapop ready-card support');
function replace(before, after) { assert.ok(source.includes(before), `Office bridge changed: ${before}`); source = source.replace(before, after); }
replace('const MAX_ATTEMPTS = 2;', 'const MAX_ATTEMPTS = 1;');
replace('const MAX_RELOADS = 1;', 'const MAX_RELOADS = 0;');
replace('const clicked = await acceptConsent(tabId);', 'const clicked = null; // Local probe never clicks consent or terms.');
replace('Math.min(remaining, PER_ATTEMPT_MS), graceMs, abandonStatuses);', 'Math.min(remaining, PER_ATTEMPT_MS), graceMs, abandonStatuses, job.keep_tab === true);');
replace('async function attemptOnce(url, timeoutMs, graceMs, abandonStatuses) {', 'async function attemptOnce(url, timeoutMs, graceMs, abandonStatuses, keepTab = false) {');
replace('chrome.tabs.create({ url, active: false })', 'chrome.tabs.create({ url, active: keepTab })');
replace('await chrome.tabs.remove(tabId);', 'if (!keepTab) await chrome.tabs.remove(tabId);');
source = source.replaceAll('final_url: doc.href,', 'final_url: doc.href, tab_id: tabId,');
await writeFile(join(output, 'office-bridge/background.js'), source);
const manifestPath = join(output, 'ane-extension/manifest.json');
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
assert.deepEqual(manifest.permissions.slice().sort(), ['activeTab', 'scripting', 'storage']);
assert.deepEqual(manifest.host_permissions, ['https://ane.deals/*', 'https://ane.coflnet.com/*']);
assert.deepEqual(manifest.content_scripts, []);
manifest.name += ' — LOCAL MOCK TEST';
manifest.host_permissions.push('http://127.0.0.1:8083/*');
await writeFile(manifestPath, JSON.stringify(manifest));
// Only the temporary test bundle points to a loopback mock API; no real Ane API writes occur.
const files = [manifest.background.service_worker];
const popup = await readFile(join(output, 'ane-extension/popup.html'), 'utf8');
files.push(/src="([^"]+\.js)"/.exec(popup)[1].replace(/^\//, ''));
let replacements = 0;
for (const file of files) {
  const path = join(output, 'ane-extension', file);
  const js = await readFile(path, 'utf8');
  replacements += js.split('https://ane.coflnet.com').length - 1;
  await writeFile(path, js.replaceAll('https://ane.coflnet.com', 'http://127.0.0.1:8083'));
}
assert.ok(replacements >= 2, 'Built API base was not found in both extension contexts');
await writeFile(join(output, 'ane-extension', manifest.background.service_worker), '\nchrome.storage.local.set({aneToken:"local-mock-only",tokenSavedAt:Date.now()});\n', { flag: 'a' });
for (const file of ['office-mock-api.py', 'office-pack-probe.sh', 'office-press-action.py', 'office-fixture-run.py', 'office-fixture-start.sh'])
  await cp(join(import.meta.dirname, file), join(output, file));
await writeFile(join(output, 'probe-metadata.json'), JSON.stringify({ mockApi: 'http://127.0.0.1:8083', productionExtensionUnchanged: true, officeSiblingUnchanged: true, attempts: 1, reloads: 0, consentClicks: false, keepTabOnlyWhenRequested: true }, null, 2));
console.log(output);
