"""Loopback-only mock capture API for the temporary normal-Chrome extension bundle."""
import json
import os
import ssl
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

captures = []
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def reply(self, status, value):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()
        self.wfile.write(body)
    def do_OPTIONS(self):
        self.reply(200, {})
    def do_GET(self):
        self.reply(200, {'mock': True, 'captures': captures} if self.path == '/results' else {'mock': True})
    def do_POST(self):
        if self.path != '/api/extension/discover' or self.headers.get('Authorization') != 'Bearer local-mock-only':
            return self.reply(401, {'mock': True})
        length = int(self.headers.get('Content-Length', '0'))
        if not 0 < length <= 32000:
            return self.reply(413, {'mock': True})
        try:
            data = json.loads(self.rfile.read(length))
            assert urlparse(data['url']).scheme == 'https' and data['title']
        except (ValueError, KeyError, AssertionError):
            return self.reply(400, {'mock': True})
        captures.append(data)
        with open(os.environ.get('ANE_MOCK_CAPTURE_PATH', '/tmp/ane-mock-captures.json'), 'w') as output:
            json.dump({'mock': True, 'captures': captures}, output)
        self.reply(200, {'listing': {'id': urlparse(data['url']).path.rstrip('/').split('/')[-1], 'platform': 'LocalMock', 'url': data['url'], 'title': data['title'], 'price': data.get('price'), 'currency': data.get('currency'), 'imageUrls': [data['imageUrl']] if data.get('imageUrl') else []}, 'stored': True, 'queued': False, 'productId': None, 'estimate': None, 'productCandidates': [], 'similarListings': []})

if os.environ.get('ANE_FIXTURE_CERT'):
    class Fixture(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def do_GET(self):
            product = {'@type': 'Product', 'url': 'https://www.vinted.de/items/123456-local-fixture', 'name': 'LOCAL FIXTURE camera', 'description': 'Synthetic local listing for extension testing.', 'datePosted': '2026-10-03T12:00:00Z', 'offers': {'price': '100.00', 'priceCurrency': 'EUR', 'availability': 'https://schema.org/InStock'}}
            html = ('<!doctype html><html lang="de-DE"><title>LOCAL FIXTURE camera</title><h1>LOCAL FIXTURE camera</h1><script type="application/ld+json">' + json.dumps(product) + '</script></html>').encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(html)))
            self.end_headers()
            self.wfile.write(html)
    fixture = ThreadingHTTPServer(('127.0.0.1', 443), Fixture)
    tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.load_cert_chain(os.environ['ANE_FIXTURE_CERT'], os.environ['ANE_FIXTURE_KEY'])
    fixture.socket = tls.wrap_socket(fixture.socket, server_side=True)
    threading.Thread(target=fixture.serve_forever, daemon=True).start()

ThreadingHTTPServer(('127.0.0.1', 8083), Handler).serve_forever()
