"""Press Ane's actual extensions-menu action through XTest in the fixed Chrome151 test desktop."""
import ctypes
import os
import time
x11 = ctypes.CDLL('libX11.so.6')
xtest = ctypes.CDLL('libXtst.so.6')
x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
x11.XOpenDisplay.restype = ctypes.c_void_p
x11.XFlush.argtypes = [ctypes.c_void_p]
x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
x11.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
x11.XDefaultRootWindow.restype = ctypes.c_ulong
x11.XQueryTree.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.POINTER(ctypes.c_ulong)), ctypes.POINTER(ctypes.c_uint)]
x11.XGetGeometry.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint)]
x11.XSetInputFocus.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
x11.XFree.argtypes = [ctypes.c_void_p]
xtest.XTestFakeMotionEvent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong]
xtest.XTestFakeButtonEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
display = x11.XOpenDisplay(os.environ.get('DISPLAY', ':98').encode())
if not display:
    raise RuntimeError('X display unavailable')
# Xvfb has no window manager to focus Chrome when its active tab changes.
root = x11.XDefaultRootWindow(display)
returned_root, parent, count = ctypes.c_ulong(), ctypes.c_ulong(), ctypes.c_uint()
children = ctypes.POINTER(ctypes.c_ulong)()
x11.XQueryTree(display, root, ctypes.byref(returned_root), ctypes.byref(parent), ctypes.byref(children), ctypes.byref(count))
target, area = None, 0
for index in range(count.value):
    geometry_root, x, y = ctypes.c_ulong(), ctypes.c_int(), ctypes.c_int()
    width, height, border, depth = (ctypes.c_uint() for _ in range(4))
    x11.XGetGeometry(display, children[index], ctypes.byref(geometry_root), ctypes.byref(x), ctypes.byref(y), ctypes.byref(width), ctypes.byref(height), ctypes.byref(border), ctypes.byref(depth))
    if width.value > 200 and height.value > 200 and width.value * height.value > area:
        target, area = children[index], width.value * height.value
x11.XFree(children)
if target is None:
    raise RuntimeError('Headed Chrome window not found for keyboard focus')
# This isolated display contains one browser and no desktop/window manager.
x11.XSetInputFocus(display, target, 2, 0)
x11.XFlush(display)
time.sleep(0.3)
# Fresh profile, 1920x1080, de-DE: Office full-access row, Ane requested-access row.
# This clicks browser chrome only, never page consent/verification controls.
for x, y in [(1816, 72), (1640, 352)]:
    xtest.XTestFakeMotionEvent(display, -1, x, y, 0)
    xtest.XTestFakeButtonEvent(display, 1, 1, 0)
    xtest.XTestFakeButtonEvent(display, 1, 0, 0)
    x11.XFlush(display)
    time.sleep(1)
x11.XCloseDisplay(display)
print('Pressed Ane extension-menu action; inspect loopback mock API /results for capture.')
