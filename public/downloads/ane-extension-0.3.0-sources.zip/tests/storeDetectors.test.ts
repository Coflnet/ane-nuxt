import { test } from 'node:test';
import assert from 'node:assert/strict';
import { listingIdentity, parsePrice, safeUrl, marketplaces, detectStorePage } from '../utils/storeDetectors.ts';

test('marketplace identities match canonical Core forms and reject deceptive hosts', () => {
  const cases = [
    ['https://www.ebay.de/itm/a-camera/123456?campaign=x', 'Ebay', '123456'],
    ['https://www.kleinanzeigen.de/s-anzeige/kamera/123456-245-1234', 'Kleinanzeigen', '123456'],
    ['https://www.vinted.lu/items/123-camera', 'Vinted', '123'],
    ['https://www.leboncoin.fr/ad/ordinateurs/123456', 'Lebecoin', '123456'],
    ['https://www.willhaben.at/iad/kaufen-und-verkaufen/d/kamera-123456', 'Willhaben', 'kaufen-und-verkaufen/d/kamera-123456'],
    ['https://www.olx.pl/d/oferta/kamera-IDabc12.html?reason=x', 'OLX', 'pl:IDabc12'],
    ['https://www.olx.pt/d/anuncio/kamera-IDabc12.html', 'OLX', 'pt:IDabc12'],
    ['https://pc.bazos.cz/inzerat/123456/kamera.php', 'Bazos', 'cz:123456'],
    ['https://www.finn.no/bap/forsale/ad.html?finnkode=123456&ad=x', 'Finn', '123456'],
    ['https://www.marktplaats.nl/v/audio/m123-camera', 'Marktplaats', 'm123'],
    ['https://www.2ememain.be/v/audio/m123-camera', 'TwoDehands', 'm123'],
    ['https://allegro.pl/oferta/kamera-123456', 'Allegro', '123456'],
    ['https://allegrolokalnie.pl/oferta/kamera-xyz', 'AllegroLokalnie', 'kamera-xyz'],
    ['https://www.dba.dk/camera/id-123456', 'DBA', '123456'],
    ['https://www.tori.fi/uusimaa/kamera_123456.htm', 'Tori', '123456'],
  ];
  for (const [url, platform, listingId] of cases) {
    assert.equal(listingIdentity(url)?.platform, platform, url);
    assert.equal(listingIdentity(url)?.listingId, listingId, url);
  }
  assert.equal(listingIdentity(cases[8][0])?.url, 'https://www.finn.no/bap/forsale/ad.html?finnkode=123456');
  for (const url of ['https://evilvinted.de/items/123', 'https://vinted.de.evil.test/items/123', 'https://vinted.de/catalog', 'https://user:pass@vinted.de/items/123', 'https://vinted.de:8443/items/123', 'https://www.cardmarket.com/en/Pokemon/Products/Singles/Card', 'https://www.finn.no/bap/forsale/ad.html?finnkode=oops']) assert.equal(listingIdentity(url), null, url);
  assert.ok(marketplaces.length >= 35);
});

test('EU and UK prices preserve decimal/thousand separators and ISO currencies', () => {
  for (const [input, price, currency] of [['1.234,56 €',1234.56,'EUR'], ['£1,234.56',1234.56,'GBP'], ['2 349,99 zł',2349.99,'PLN'], ['1\u202f200,50 Kč',1200.5,'CZK'], ['EUR 0',0,'EUR'], ['1,234 USD',1234,'USD']]) assert.deepEqual(parsePrice(String(input)), { price, currency });
  assert.equal(parsePrice('-100 €').price, undefined);
  assert.equal(parsePrice('Ask seller').price, undefined);
});

test('unsafe page and returned listing URLs cannot be rendered as links', () => {
  assert.equal(safeUrl('javascript:alert(1)'), undefined);
  assert.equal(safeUrl('data:text/html,test'), undefined);
  assert.equal(safeUrl('https://user:secret@example.com'), undefined);
  assert.equal(safeUrl('/image.jpg', 'https://www.vinted.de/items/123'), 'https://www.vinted.de/image.jpg');
});

// Narrow fake DOM exercises metadata selection without adding a DOM library dependency.
function documentWith(products: unknown[], title = 'Current listing'): Document {
  return {
    documentElement: { lang: 'de' },
    querySelectorAll: () => [{ textContent: JSON.stringify(products) }],
    querySelector: (selector: string) => selector.includes('h1') ? { textContent: title } : null,
  } as unknown as Document;
}

test('extractor ignores recommended product metadata and sold stock', () => {
  const current = 'https://www.vinted.de/items/123-camera';
  const doc = documentWith([{ '@type': 'Product', url: 'https://www.ebay.de/itm/123', name: 'Wrong product', offers: { price: 999, priceCurrency: 'EUR' } }]);
  const listing = detectStorePage(doc, current)!;
  assert.equal(listing.title, 'Current listing'); assert.equal(listing.price, undefined);
  const sold = detectStorePage(documentWith([{ '@type': 'Product', url: current, name: 'Camera', offers: { price: '1.99', priceCurrency: 'EUR', availability: 'https://schema.org/OutOfStock' }, image: 'javascript:alert(1)' }]), current)!;
  assert.equal(sold.price, 1.99); assert.equal(sold.currency, 'EUR'); assert.equal(sold.availability, 'unavailable'); assert.equal(sold.imageUrl, undefined);
});

test('listing age uses only matched publisher posted/published timestamps', () => {
  const url = 'https://www.leboncoin.fr/ad/ordinateurs/123456';
  const product = { '@type': 'Product', url, name: 'Computer', datePosted: '2026-10-03T12:00:00Z' };
  assert.equal(detectStorePage(documentWith([product]), url)?.createdAt, '2026-10-03T12:00:00.000Z');
  for (const fields of [{ dateModified: '2026-10-03T12:00:00Z' }, { datePublished: 'not a date' }, { datePublished: '2999-01-01T12:00:00Z' }])
    assert.equal(detectStorePage(documentWith([{ '@type': 'Product', url, name: 'Computer', ...fields }]), url)?.createdAt, undefined);
});
