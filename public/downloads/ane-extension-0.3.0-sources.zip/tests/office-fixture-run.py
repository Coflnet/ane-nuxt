"""Headed normal-Chrome explicit action on a synthetic listing, with a loopback mock API."""
import asyncio
import json
import logging
import os
import subprocess
import uuid
from pathlib import Path
from urllib.request import urlopen
from aiohttp import web
import bridge
import supervisor

logging.basicConfig(level=logging.CRITICAL)
original_launch = supervisor.launch_browser
def fixture_launch(binary, config):
    original_popen = supervisor.subprocess.Popen
    def with_fixture(args, *positional, **keywords):
        args = args[:-1] + ['--host-resolver-rules=MAP www.vinted.de 127.0.0.1', '--ignore-certificate-errors-spki-list=' + os.environ['ANE_FIXTURE_SPKI']] + args[-1:]
        return original_popen(args, *positional, **keywords)
    supervisor.subprocess.Popen = with_fixture
    try:
        return original_launch(binary, config)
    finally:
        supervisor.subprocess.Popen = original_popen
supervisor.launch_browser = fixture_launch

def captures():
    with urlopen('http://127.0.0.1:8083/results', timeout=3) as response:
        return json.load(response)['captures']

async def main():
    static = web.Application()
    static.router.add_static('/', '/tmp/ane-normal-chrome-probe/ane-crx')
    server = web.AppRunner(static); await server.setup()
    await web.TCPSite(server, '127.0.0.1', 8082).start()
    await bridge.serve_loopback()
    task = asyncio.create_task(supervisor.supervise())
    try:
        for _ in range(90):
            if bridge.connected(): break
            if task.done(): await task
            await asyncio.sleep(1)
        else: raise RuntimeError('Normal Chrome bridge did not connect')
        browser = bridge.BROWSERS[0]
        profile = Path('/tmp/bridge-profile-' + browser.label + '/Default/Extensions')
        for _ in range(30):
            installed = [name for name in ('office', 'ane') if (profile / Path('/tmp/ane-normal-chrome-probe/' + name + '-crx/extension-id').read_text().strip()).exists()]
            if len(installed) == 2: break
            await asyncio.sleep(1)
        assert len(installed) == 2, 'Both enterprise policy extensions must be installed'
        job = uuid.uuid4().hex
        browser.pending[job] = asyncio.get_running_loop().create_future()
        browser.acks[job] = asyncio.get_running_loop().create_future()
        try:
            await browser.ws.send_json({'id': job, 'url': 'https://www.vinted.de/items/123456-local-fixture', 'timeout_ms': 7000, 'keep_tab': True})
            await asyncio.wait_for(browser.acks[job], 10)
            navigation = await asyncio.wait_for(browser.pending[job], 15)
        finally:
            browser.pending.pop(job, None); browser.acks.pop(job, None)
        print(json.dumps({'fixture_navigation': {key: navigation.get(key) for key in ('ok', 'status', 'title', 'reason', 'html_len', 'body_text')}}), flush=True)
        assert navigation.get('title') == 'LOCAL FIXTURE camera', 'Synthetic HTTPS listing did not load'
        await asyncio.sleep(2)
        assert not captures(), 'Navigation must not collect the listing'
        subprocess.run(['python', '/probe/office-press-action.py'], check=True)
        for _ in range(20):
            collected = captures()
            if collected: break
            await asyncio.sleep(1)
        listing = collected[0] if collected else None
        if listing:
            assert listing['url'] == 'https://www.vinted.de/items/123456-local-fixture'
            assert listing['title'] == 'LOCAL FIXTURE camera' and listing['price'] == 100 and listing['currency'] == 'EUR'
            assert listing['availability'] == 'available' and listing['createdAt'] == '2026-10-03T12:00:00.000Z'
        result = {'browser': subprocess.check_output(['google-chrome', '--version'], text=True).strip(), 'headed': True,
                  'installed_extensions': installed, 'fixture': 'synthetic HTTPS; www.vinted.de mapped to loopback',
                  'api': 'loopback mock; dummy auth; no production persistence', 'passive_captures': 0, 'action_captures': len(collected), 'listing': listing}
        Path('/results/action-result.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
        assert len(collected) == 1, 'One explicit browser action must capture exactly one listing'
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        await server.cleanup()

asyncio.run(main())
