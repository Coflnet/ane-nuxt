#!/bin/bash
# Run only inside a disposable local OfficeScraper container, before starting Chrome.
set -euo pipefail
probe_root="${1:-/probe}"
task_root=/tmp/ane-normal-chrome-probe
mkdir -p "$task_root"
cp -R "$probe_root/office-bridge" "$task_root/office-bridge"
cp -R "$probe_root/ane-extension" "$task_root/ane-extension"
/app/pack-extension.sh "$task_root/office-bridge" "$task_root/office-crx" 8081
cp /etc/opt/chrome/policies/managed/office-scraper-bridge.json "$task_root/office-policy.json"
/app/pack-extension.sh "$task_root/ane-extension" "$task_root/ane-crx" 8082
python - "$task_root" <<'PY'
import json,sys
root=sys.argv[1]
path='/etc/opt/chrome/policies/managed/office-scraper-bridge.json'
first=json.load(open(root+'/office-policy.json'))
second=json.load(open(path))
for key in ('ExtensionInstallForcelist','ExtensionInstallSources'):
    second[key]=first[key]+second[key]
with open(path,'w') as output: json.dump(second,output)
PY
echo "Local policy packages ready in $task_root; serve ane-crx on loopback8082, Office bridge on8081."
