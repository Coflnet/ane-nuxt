#!/bin/bash
set -euo pipefail
bash /probe/office-pack-probe.sh
openssl req -x509 -newkey rsa:2048 -nodes -keyout /tmp/fixture.key -out /tmp/fixture.crt -days 1 -subj '/CN=www.vinted.de' -addext 'subjectAltName=DNS:www.vinted.de' >/dev/null 2>&1
export ANE_FIXTURE_CERT=/tmp/fixture.crt ANE_FIXTURE_KEY=/tmp/fixture.key
ANE_FIXTURE_SPKI=$(openssl x509 -in /tmp/fixture.crt -pubkey -noout | openssl pkey -pubin -outform DER 2>/dev/null | openssl dgst -sha256 -binary | openssl base64 -A)
export ANE_FIXTURE_SPKI PYTHONPATH=/office
export OFFICE_SCRAPER_BRIDGE_MODE=only OFFICE_SCRAPER_BRIDGE_BROWSERS=1 OFFICE_SCRAPER_BRIDGE_JOBS_PER_BROWSER=1
export OFFICE_SCRAPER_BRIDGE_BROWSER=/usr/bin/google-chrome
export OFFICE_SCRAPER_BRIDGE_EXTENSION_DIR=/tmp/ane-normal-chrome-probe/office-bridge
export OFFICE_SCRAPER_BRIDGE_CRX_DIR=/tmp/ane-normal-chrome-probe/office-crx
export OFFICE_SCRAPER_BRIDGE_RECYCLE_AFTER_JOBS=0 OFFICE_SCRAPER_BRIDGE_RECYCLE_AFTER_SECONDS=0
python /probe/office-mock-api.py &
exec python /probe/office-fixture-run.py
