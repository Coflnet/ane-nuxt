using Coflnet.Ane.ReferenceListings;
var builder = WebApplication.CreateBuilder(args);
builder.Logging.ClearProviders();
var app = builder.Build();
var service = new ReferenceListingPreviewService();
app.MapPost("/api/reference-listings/preview", (ReferenceListingPreviewRequest request) =>
    service.Build(new Uri(request.Url), request.Url.Contains("private")
        ? "<html><head><title>Sign in</title></head><body><span id='other'>999 €</span></body></html>"
        : "<html><head><title>Camera</title></head><body><span id='reference-price'>100,00 €</span><span id='reference-shipping'>5,00 €</span></body></html>",
        request.SelectedSelector, request.AdditionalSelectors));
app.Run("http://127.0.0.1:4174");
