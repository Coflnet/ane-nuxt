# Normal Chrome local extension check

This harness reuses the sibling OfficeScraper's headed Google Chrome and enterprise-policy CRX installation. It does not modify OfficeScraper, the production Ane bundle, deployed workloads or real account data. Chrome is launched normally, without CDP, remote debugging, Playwright or stealth patches.

Prepare temporary bundles from the current Chrome build:

```sh
cd AneExension
node tests/prepare-office-probe.mjs /tmp/ane-office-probe-20261004
```

Mount that output read-only at `/probe` in a **disposable** container using the cached `officescraper:chrome` image. Run `bash /probe/office-pack-probe.sh` before starting Chrome. It packages the Office bridge and Ane test bundle separately, then combines their enterprise policies. Serve the resulting `/tmp/ane-normal-chrome-probe/office-crx` through the existing loopback bridge on 8081 and `ane-crx` through a loopback HTTP server on 8082. Packaging changes policy only inside this test container.

The copied Office bridge retains the existing request protocol and ordinary browser rendering wait. It runs one attempt, performs no explicit reload and clicks no consent, terms or human verification controls. A job with `keep_tab:true` retains and activates its page for a subsequent explicit Ane action. Other jobs close their tabs normally.

Start `python /probe/office-mock-api.py` in the container. The temporary Ane bundle differs from the shipping bundle only by its **LOCAL MOCK TEST** name, a loopback API permission/base and a fixed dummy token in extension storage. It sends capture requests only to `127.0.0.1:8083`; no real Ane API write occurs. The mock returns no estimate or comparison inventory. “Listing saved” in this variant means the local mock recorded the request, not that the production database stored anything.

After an individual listing is active in the browser, run `DISPLAY=:98 python /probe/office-press-action.py`. XTest focuses the sole browser window and clicks Chrome's extensions menu and Ane action, giving the actual extension its normal `activeTab` grant. Coordinates target the cached Chrome151, 1920x1080, de-DE desktop with only Office and Ane installed; this is a test driver for that fixed environment. Read `http://127.0.0.1:8083/results` from the controller, or inspect `/tmp/ane-mock-captures.json`. This confirms canonical extraction and the request contract on the visible page. Merely navigating must produce zero captures.

For a fully local synthetic listing, generate a one-day test certificate for `www.vinted.de` inside the disposable container, set `ANE_FIXTURE_CERT`/`ANE_FIXTURE_KEY` when starting the mock server, and use a separate Chrome profile with `--host-resolver-rules=MAP www.vinted.de 127.0.0.1`. Trust that local certificate or use `--ignore-certificate-errors-spki-list` with **only its public-key fingerprint**. Open `https://www.vinted.de/items/123456-local-fixture`; no marketplace request occurs. Keep this fixture configuration separate from live availability checks. Do not use a blanket certificate-error bypass.

`bash tests/office-fixture-launch.sh /tmp/ane-chrome-action-results` runs that synthetic action check automatically through the actual Office supervisor and Chrome UI, using the cached image. It verifies both policy-installed extensions, zero captures on navigation, and one action capture with exact identity/title/price/currency/availability/posted date. Chrome uses normal headed launch flags; the only fixture additions are local DNS mapping and its certificate's scoped public-key trust. The disposable container and temporary packages are removed automatically. The retained `action-result.json` is credential-free and explicitly labels the fixture/mock backend.

ISP proxy availability and extension functionality are separate results. A provider CONNECT denial occurs before the marketplace is reached; stop that route after the first denial. Fixture/mock success establishes browser installation and action/capture behavior, not live marketplace access or persistence. Keep reports credential-free and remove the disposable container, its policies, profile, certificate and temporary bundles after the check. Credential artifacts, if used by a separate authorized proxy setup, must be removed by their owner.
