#!/bin/bash
set -euo pipefail
task_root=$(cd "$(dirname "$0")/.." && pwd)
task_output=${1:-$(mktemp -d /tmp/ane-chrome-action-results.XXXXXX)}
task_prepared=$(mktemp -d /tmp/ane-chrome-action-packages.XXXXXX)
task_container="ane-chrome-action-$$"
trap 'docker rm -f "$task_container" >/dev/null 2>&1 || true; rm -rf "$task_prepared"' EXIT
mkdir -p "$task_output"
node "$task_root/tests/prepare-office-probe.mjs" "$task_prepared"
echo "Local mock action result: $task_output/action-result.json"
timeout 240 docker run --rm --init --name "$task_container" --cpus 2 --memory 2g --shm-size 256m \
    --volume "$task_root/../../Cait/OfficeScraper:/office:ro" --volume "$task_prepared:/probe:ro" \
    --volume "$task_output:/results" --entrypoint bash "${ANE_CHROME_IMAGE:-officescraper:chrome}" /probe/office-fixture-start.sh
